# مساعد مهندس الكهرباء | Electrical Engineer Assistant

تطبيق Android مبني باستخدام Kotlin و Jetpack Compose، ويضم أدوات وحاسبات كهربائية ومساعدًا ذكيًا يعتمد على Gemini.

## Build APK

يتم بناء نسخة Debug تلقائيًا عند كل Push إلى `main`، أو يدويًا من تبويب **Actions** عبر workflow باسم **Android APK Build**.

بعد نجاح البناء، نزّل الملف من:
**Actions → أحدث عملية Build → Artifacts → Electrical-Assistant-debug-apk**

## Gemini API key

لا تضع مفتاح Gemini الحقيقي داخل Git أو داخل ملفات المشروع.
ملف `.env.example` يحتوي قيمة تجريبية فقط. إعداد المفتاح داخل التطبيق يحتاج معالجة آمنة قبل توزيع نسخة عامة؛ تضمين مفتاح API داخل APK قد يسمح باستخراجه.

## Project

- Android / Kotlin
- Jetpack Compose
- Minimum SDK: 24 (Android 7.0)
