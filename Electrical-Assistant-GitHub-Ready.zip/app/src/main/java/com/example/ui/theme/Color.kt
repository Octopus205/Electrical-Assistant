package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Professional Polish Color Theme (M3 Dark/Light Palette)
val PrimaryPurple = Color(0xFFD0BCFF)
val OnPrimaryPurple = Color(0xFF381E72)
val PrimaryContainerPurple = Color(0xFF4F378B)
val OnPrimaryContainerPurple = Color(0xFFEADDFF)

val SecondaryPurple = Color(0xFFCCC2DC)
val OnSecondaryPurple = Color(0xFF332D41)

val TertiaryBlue = Color(0xFFBAC3FF)
val OnTertiaryBlue = Color(0xFF001945)

val AppBackground = Color(0xFF1C1B1F)
val AppSurface = Color(0xFF2B2930)
val OnAppSurface = Color(0xFFE6E1E5)

val CardSurfaceVariant = Color(0xFF49454F)
val BorderOutline = Color(0xFF938F99)
val BorderOutlineVariant = Color(0xFF49454F)

// Highlight / Specific card colors from design
val BerryDark = Color(0xFF31111D)
val BerryLight = Color(0xFFFFD8E4)

val VioletDark = Color(0xFF2B2930)
val VioletLight = Color(0xFFD0BCFF)

val GreenDark = Color(0xFF1D2B1C)
val GreenLight = Color(0xFFB4EBAF)

