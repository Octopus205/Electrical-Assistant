package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.models.SymbolDrawType

@Composable
fun ElectricalSymbolVisual(
    drawType: SymbolDrawType,
    modifier: Modifier = Modifier,
    color: Color = Color.Black
) {
    Canvas(modifier = modifier.size(120.dp)) {
        val w = size.width
        val h = size.height
        val cx = w / 2
        val cy = h / 2
        val strokeWidth = 3.dp.toPx()

        when (drawType) {
            SymbolDrawType.RESISTOR -> {
                // Classic Zigzag US standard or Rectangular IEC layout. Zigzag is highly recognizable
                val path = Path().apply {
                    moveTo(0f, cy)
                    lineTo(cx - 40f, cy)
                    lineTo(cx - 30f, cy - 25f)
                    lineTo(cx - 10f, cy + 25f)
                    lineTo(cx + 10f, cy - 25f)
                    lineTo(cx + 30f, cy + 25f)
                    lineTo(cx + 40f, cy)
                    lineTo(w, cy)
                }
                drawPath(path = path, color = color, style = Stroke(width = strokeWidth, cap = StrokeCap.Round))
            }
            SymbolDrawType.CAPACITOR -> {
                // Connecting lines and two parallel plates
                drawLine(color = color, start = androidx.compose.ui.geometry.Offset(0f, cy), end = androidx.compose.ui.geometry.Offset(cx - 15f, cy), strokeWidth = strokeWidth, cap = StrokeCap.Round)
                drawLine(color = color, start = androidx.compose.ui.geometry.Offset(cx + 15f, cy), end = androidx.compose.ui.geometry.Offset(w, cy), strokeWidth = strokeWidth, cap = StrokeCap.Round)
                // Plates
                drawLine(color = color, start = androidx.compose.ui.geometry.Offset(cx - 15f, cy - 35f), end = androidx.compose.ui.geometry.Offset(cx - 15f, cy + 35f), strokeWidth = strokeWidth + 2f, cap = StrokeCap.Round)
                drawLine(color = color, start = androidx.compose.ui.geometry.Offset(cx + 15f, cy - 35f), end = androidx.compose.ui.geometry.Offset(cx + 15f, cy + 35f), strokeWidth = strokeWidth + 2f, cap = StrokeCap.Round)
            }
            SymbolDrawType.INDUCTOR -> {
                // Series of elegant coils
                val path = Path().apply {
                    moveTo(0f, cy)
                    lineTo(cx - 45f, cy)
                    // First loop
                    cubicTo(cx - 45f, cy, cx - 35f, cy - 30f, cx - 22.5f, cy)
                    // Second loop
                    cubicTo(cx - 22.5f, cy, cx - 12.5f, cy - 30f, cx, cy)
                    // Third loop
                    cubicTo(cx, cy, cx + 10f, cy - 30f, cx + 22.5f, cy)
                    // Fourth loop
                    cubicTo(cx + 22.5f, cy, cx + 32.5f, cy - 30f, cx + 45f, cy)
                    lineTo(w, cy)
                }
                drawPath(path = path, color = color, style = Stroke(width = strokeWidth, cap = StrokeCap.Round))
            }
            SymbolDrawType.DIODE -> {
                // DIODE arrow and bar
                drawLine(color = color, start = androidx.compose.ui.geometry.Offset(0f, cy), end = androidx.compose.ui.geometry.Offset(cx - 20f, cy), strokeWidth = strokeWidth, cap = StrokeCap.Round)
                drawLine(color = color, start = androidx.compose.ui.geometry.Offset(cx + 20f, cy), end = androidx.compose.ui.geometry.Offset(w, cy), strokeWidth = strokeWidth, cap = StrokeCap.Round)
                
                // Triangular arrow
                val path = Path().apply {
                    moveTo(cx - 20f, cy - 25f)
                    lineTo(cx + 15f, cy)
                    lineTo(cx - 20f, cy + 25f)
                    close()
                }
                drawPath(path = path, color = color)
                
                // Vertical blocking line
                drawLine(color = color, start = androidx.compose.ui.geometry.Offset(cx + 18f, cy - 25f), end = androidx.compose.ui.geometry.Offset(cx + 18f, cy + 25f), strokeWidth = strokeWidth + 1f, cap = StrokeCap.Round)
            }
            SymbolDrawType.GROUND -> {
                // Vertical center entry line
                drawLine(color = color, start = androidx.compose.ui.geometry.Offset(cx, 0f), end = androidx.compose.ui.geometry.Offset(cx, cy + 10f), strokeWidth = strokeWidth, cap = StrokeCap.Round)
                // 3 descending lines
                drawLine(color = color, start = androidx.compose.ui.geometry.Offset(cx - 35f, cy + 10f), end = androidx.compose.ui.geometry.Offset(cx + 35f, cy + 10f), strokeWidth = strokeWidth, cap = StrokeCap.Round)
                drawLine(color = color, start = androidx.compose.ui.geometry.Offset(cx - 22f, cy + 23f), end = androidx.compose.ui.geometry.Offset(cx + 22f, cy + 23f), strokeWidth = strokeWidth, cap = StrokeCap.Round)
                drawLine(color = color, start = androidx.compose.ui.geometry.Offset(cx - 10f, cy + 36f), end = androidx.compose.ui.geometry.Offset(cx + 10f, cy + 36f), strokeWidth = strokeWidth, cap = StrokeCap.Round)
            }
            SymbolDrawType.DC_SOURCE -> {
                // Connecting lines
                drawLine(color = color, start = androidx.compose.ui.geometry.Offset(0f, cy), end = androidx.compose.ui.geometry.Offset(cx - 10f, cy), strokeWidth = strokeWidth, cap = StrokeCap.Round)
                drawLine(color = color, start = androidx.compose.ui.geometry.Offset(cx + 10f, cy), end = androidx.compose.ui.geometry.Offset(w, cy), strokeWidth = strokeWidth, cap = StrokeCap.Round)
                // Long plate (+)
                drawLine(color = color, start = androidx.compose.ui.geometry.Offset(cx - 10f, cy - 30f), end = androidx.compose.ui.geometry.Offset(cx - 10f, cy + 30f), strokeWidth = strokeWidth + 1f, cap = StrokeCap.Round)
                // Short plate (-)
                drawLine(color = color, start = androidx.compose.ui.geometry.Offset(cx + 10f, cy - 15f), end = androidx.compose.ui.geometry.Offset(cx + 10f, cy + 15f), strokeWidth = strokeWidth + 4f, cap = StrokeCap.Round)
            }
            SymbolDrawType.AC_SOURCE -> {
                // Leading lines
                drawLine(color = color, start = androidx.compose.ui.geometry.Offset(0f, cy), end = androidx.compose.ui.geometry.Offset(cx - 30f, cy), strokeWidth = strokeWidth, cap = StrokeCap.Round)
                drawLine(color = color, start = androidx.compose.ui.geometry.Offset(cx + 30f, cy), end = androidx.compose.ui.geometry.Offset(w, cy), strokeWidth = strokeWidth, cap = StrokeCap.Round)
                // Outer circle
                drawCircle(color = color, radius = 30f, center = androidx.compose.ui.geometry.Offset(cx, cy), style = Stroke(width = strokeWidth))
                // Sine wave inside circle
                val path = Path().apply {
                    moveTo(cx - 18f, cy)
                    cubicTo(cx - 18f, cy, cx - 9f, cy - 15f, cx, cy)
                    cubicTo(cx, cy, cx + 9f, cy + 15f, cx + 18f, cy)
                }
                drawPath(path = path, color = color, style = Stroke(width = strokeWidth - 1f, cap = StrokeCap.Round))
            }
            SymbolDrawType.TRANSFORMER -> {
                // Overlapping windings (Primary & Secondary) with dual mutual induction bars
                val pathPrimary = Path().apply {
                    moveTo(0f, cy)
                    lineTo(cx - 40f, cy)
                    cubicTo(cx - 40f, cy, cx - 35f, cy - 25f, cx - 30f, cy)
                    cubicTo(cx - 30f, cy, cx - 25f, cy - 25f, cx - 20f, cy)
                    cubicTo(cx - 20f, cy, cx - 15f, cy - 25f, cx - 10f, cy)
                    lineTo(cx - 10f, h) // Primary ground or endpoint
                }
                drawPath(path = pathPrimary, color = color, style = Stroke(width = strokeWidth, cap = StrokeCap.Round))

                val pathSecondary = Path().apply {
                    moveTo(w, cy)
                    lineTo(cx + 40f, cy)
                    cubicTo(cx + 40f, cy, cx + 35f, cy - 25f, cx + 30f, cy)
                    cubicTo(cx + 30f, cy, cx + 25f, cy - 25f, cx + 20f, cy)
                    cubicTo(cx + 20f, cy, cx + 15f, cy - 25f, cx + 10f, cy)
                    lineTo(cx + 10f, h)
                }
                drawPath(path = pathSecondary, color = color, style = Stroke(width = strokeWidth, cap = StrokeCap.Round))

                // Core coupling center iron lines
                drawLine(color = color, start = androidx.compose.ui.geometry.Offset(cx - 4f, cy - 20f), end = androidx.compose.ui.geometry.Offset(cx - 4f, cy + 10f), strokeWidth = strokeWidth / 1.5f, cap = StrokeCap.Round)
                drawLine(color = color, start = androidx.compose.ui.geometry.Offset(cx + 4f, cy - 20f), end = androidx.compose.ui.geometry.Offset(cx + 4f, cy + 10f), strokeWidth = strokeWidth / 1.5f, cap = StrokeCap.Round)
            }
        }
    }
}
