package com.example.ui

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.ProjectRepository
import com.example.data.SavedProject
import com.example.models.ElectricalDataProvider
import com.example.models.QuizQuestion
import com.example.network.GeminiClient
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.math.acos
import kotlin.math.tan

class ElectricalViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: ProjectRepository

    init {
        val database = AppDatabase.getDatabase(application)
        repository = ProjectRepository(database.projectDao())
    }

    // Observed Flow of saved projects
    val savedProjects: StateFlow<List<SavedProject>> = repository.allProjects
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun saveProject(title: String, category: String, summary: String, details: String) {
        viewModelScope.launch {
            repository.insert(
                SavedProject(
                    title = title,
                    category = category,
                    summary = summary,
                    details = details
                )
            )
        }
    }

    fun deleteProject(id: Int) {
        viewModelScope.launch {
            repository.deleteById(id)
        }
    }


    // ==========================================
    // 1. CALCULATOR STATES & CALCULATIONS
    // ==========================================

    // A. Wire Sizer Calculator State
    var wsPowerKw by mutableStateOf("15.0")
    var wsIsThreePhase by mutableStateOf(true)
    var wsVoltage by mutableStateOf("380")
    var wsPowerFactor by mutableStateOf("0.85")
    var wsLengthMeters by mutableStateOf("150")
    var wsMaxDropPct by mutableStateOf("3.0")

    var wsResultCurrent by mutableStateOf(0.0)
    var wsResultSize by mutableStateOf(0.0)
    var wsResultDropPct by mutableStateOf(0.0)
    var wsResultDropVolts by mutableStateOf(0.0)
    var wsResultIsSafe by mutableStateOf(true)
    var wsResultReport by mutableStateOf("")

    fun calculateWireSize() {
        val p = wsPowerKw.toDoubleOrNull() ?: 0.0
        val is3Ph = wsIsThreePhase
        val v = wsVoltage.toDoubleOrNull() ?: 380.0
        val pf = wsPowerFactor.toDoubleOrNull() ?: 0.85
        val len = wsLengthMeters.toDoubleOrNull() ?: 1.0
        val targetDrop = wsMaxDropPct.toDoubleOrNull() ?: 3.0

        if (p <= 0 || v <= 0 || pf <= 0 || len <= 0) return

        // 1. Calculate Current
        val current = if (is3Ph) {
            (p * 1000.0) / (1.732 * v * pf)
        } else {
            (p * 1000.0) / (v * pf)
        }
        wsResultCurrent = current

        // Standard cable sizes (Copper) in mm² and their rated max ground currents (approx codes)
        val sizes = listOf(1.5, 2.5, 4.0, 6.0, 10.0, 16.0, 25.0, 35.0, 50.0, 70.0, 95.0, 120.0, 150.0)
        val ampacities = mapOf(
            1.5 to 16.0, 2.5 to 22.0, 4.0 to 30.0, 6.0 to 38.0, 10.0 to 52.0, 16.0 to 70.0,
            25.0 to 92.0, 35.0 to 114.0, 50.0 to 138.0, 70.0 to 175.0, 95.0 to 212.0, 120.0 to 245.0, 150.0 to 280.0
        )

        val rhoCopper = 0.0175 // Resistance in Ohm * mm² / m at 20°C
        var recommendedSize = 1.5
        var actualDropPct = 100.0
        var actualDropVolts = 0.0
        var isSafe = false

        for (size in sizes) {
            // Ampacity safety check
            val maxAmps = ampacities[size] ?: 0.0
            if (maxAmps < current) continue

            // Voltage drop calculation
            val dropVolts = if (is3Ph) {
                1.732 * current * len * rhoCopper / size
            } else {
                2.0 * current * len * rhoCopper / size
            }
            val dropPct = (dropVolts / v) * 100.0

            if (dropPct <= targetDrop) {
                recommendedSize = size
                actualDropPct = dropPct
                actualDropVolts = dropVolts
                isSafe = true
                break
            }
            // Keep last as fallback
            recommendedSize = size
            actualDropPct = dropPct
            actualDropVolts = dropVolts
        }

        wsResultSize = recommendedSize
        wsResultDropPct = actualDropPct
        wsResultDropVolts = actualDropVolts
        wsResultIsSafe = isSafe

        wsResultReport = "المعطيات وتحليل النتائج:\n" +
                "- لقرأة حمل قدرته ${p} كيلو واط، بتيار مسحوب مقداره ${String.format("%.2f", current)} أمبير.\n" +
                "- المقطع النحاسي الآمن الموصى به: ${recommendedSize} مم².\n" +
                "- هبوط الجهد الحاصل هو ${String.format("%.2f", actualDropVolts)} فولت، بنسبة ${String.format("%.2f", actualDropPct)}% وهو " +
                (if (isSafe) "ضمن المسموح المعياري (أقل من %$targetDrop)." else "يتجاوز النسبة المعيارية، ولكنه أكبر حجم سلك بالمنظومة للوقاية.")
    }


    // B. Cable Voltage Drop Calculator State
    var vdCurrent by mutableStateOf("25.0")
    var vdLen by mutableStateOf("100")
    var vdArea by mutableStateOf("6.0")
    var vdVoltage by mutableStateOf("220")
    var vdIsThreePhase by mutableStateOf(false)

    var vdResultDropVolts by mutableStateOf(0.0)
    var vdResultDropPct by mutableStateOf(0.0)
    var vdReport by mutableStateOf("")

    fun calculateVoltageDropOnly() {
        val i = vdCurrent.toDoubleOrNull() ?: 0.0
        val len = vdLen.toDoubleOrNull() ?: 1.0
        val area = vdArea.toDoubleOrNull() ?: 1.5
        val v = vdVoltage.toDoubleOrNull() ?: 220.0
        val is3Ph = vdIsThreePhase

        if (i <= 0 || len <= 0 || area <= 0 || v <= 0) return

        val rho = 0.0175 // Copper resistivity
        val dropVolts = if (is3Ph) {
            1.732 * i * len * rho / area
        } else {
            2.0 * i * len * rho / area
        }
        val dropPct = (dropVolts / v) * 100.0

        vdResultDropVolts = dropVolts
        vdResultDropPct = dropPct
        vdReport = "نتائج تحليل هبوط الجهد:\n" +
                "- قيمة الهبوط الفعلي: ${String.format("%.2f", dropVolts)} فولت.\n" +
                "- نسبة الهبوط: ${String.format("%.2f", dropPct)}% من جهد المصدر الأصلي.\n" +
                "- مقاومة الخط الإجمالية: ${String.format("%.4f", (dropVolts / i))} أوم.\n" +
                "- حالة الجهد عند نهاية الخط: ${String.format("%.1f", (v - dropVolts))} فولت."
    }


    // C. Motor Current & FLA Calculator State
    var mtPower by mutableStateOf("10.0")
    var mtPowerUnitHp by mutableStateOf(true) // true = HP, false = kW
    var mtVoltage by mutableStateOf("380")
    var mtEfficiency by mutableStateOf("88")
    var mtPowerFactor by mutableStateOf("0.82")
    var mtIsThreePhase by mutableStateOf(true)

    var mtResultAmps by mutableStateOf(0.0)
    var mtReport by mutableStateOf("")

    fun calculateMotorFla() {
        val rawPower = mtPower.toDoubleOrNull() ?: 0.0
        val isHp = mtPowerUnitHp
        val v = mtVoltage.toDoubleOrNull() ?: 380.0
        val eff = (mtEfficiency.toDoubleOrNull() ?: 88.0) / 100.0
        val pf = mtPowerFactor.toDoubleOrNull() ?: 0.82
        val is3Ph = mtIsThreePhase

        if (rawPower <= 0 || v <= 0 || eff <= 0 || pf <= 0) return

        // Convert HP to Kw if necessary
        val pWatts = if (isHp) {
            rawPower * 746.0
        } else {
            rawPower * 1000.0
        }

        val current = if (is3Ph) {
            pWatts / (1.732 * v * pf * eff)
        } else {
            pWatts / (v * pf * eff)
        }

        mtResultAmps = current
        mtReport = "تحليل تيار الحمل الكامل للمحرك (FLA):\n" +
                "- تيار التشغيل المقنن: ${String.format("%.2f", current)} أمبير.\n" +
                "- تيار الإقلاع المتوقع (Direct Online): ${String.format("%.2f", current * 6.5)} أمبير (بمتوسط 6.5 أضعاف).\n" +
                "- تيار إقلاع بنظام ستار-دلتا مقترح: ${String.format("%.2f", (current * 6.5) / 3.0)} أمبير."
    }


    // D. Power Factor Correction Calculator State
    var pfCurrentPowerKw by mutableStateOf("50.0")
    var pfOldPf by mutableStateOf("0.70")
    var pfTargetPf by mutableStateOf("0.95")
    var pfVoltage by mutableStateOf("380")
    var pfFrequencyHz by mutableStateOf("50")

    var pfResultCapacitorKvar by mutableStateOf(0.0)
    var pfResultCapacitanceUf by mutableStateOf(0.0)
    var pfReport by mutableStateOf("")

    fun calculatePowerFactorCorrection() {
        val pKw = pfCurrentPowerKw.toDoubleOrNull() ?: 0.0
        val oldPf = pfOldPf.toDoubleOrNull() ?: 0.7
        val targetPf = pfTargetPf.toDoubleOrNull() ?: 0.95
        val v = pfVoltage.toDoubleOrNull() ?: 380.0
        val freq = pfFrequencyHz.toDoubleOrNull() ?: 50.0

        if (pKw <= 0 || oldPf <= 0.2 || oldPf >= 1.0 || targetPf <= 0.5 || targetPf > 1.0 || v <= 0) return

        try {
            val angleOld = acos(oldPf)
            val angleTarget = acos(targetPf)

            // Qc = P * (tan(old) - tan(target))
            val kvarRequired = pKw * (tan(angleOld) - tan(angleTarget))

            // For dynamic capacitance in 3-phase star connected capacitor bank
            // C = QC_phase / (2 * pi * f * V_phase^2)
            // V_phase = V / sqrt(3). V_phase^2 = V^2 / 3. QC_phase = Qc / 3.
            // C_phase = (Qc/3) / (2 * pi * f * V^2 / 3) = Qc / (2 * pi * f * V^2)
            val cFarad = (kvarRequired * 1000.0) / (2 * Math.PI * freq * v * v)
            val cMicroFarad = cFarad * 1_000_000.0

            pfResultCapacitorKvar = kvarRequired
            pfResultCapacitanceUf = cMicroFarad

            pfReport = "خطة تحسين جودة الطاقة ومعامل القدرة:\n" +
                    "- سعة بنك المكثفات المطلوبة: ${String.format("%.2f", kvarRequired)} كيلو فار (kVAr).\n" +
                    "- سعة كل مكثف بالدلتا/ستار: ${String.format("%.2f", cMicroFarad)} ميكروفاراد (μF).\n" +
                    "- توفير فاقد التيار المتوقع: تقليل التيار المغذي الإجمالي بنسبة تقارب ${String.format("%.1f", (1.0 - (oldPf / targetPf)) * 100)}% مما يرشّد الكابلات."
        } catch (e: Exception) {
            pfReport = "خطأ في المدخلات الرياضية للزاوية الجيبية المتناظرة."
        }
    }


    // ==========================================
    // 2. SMART CIRCUIT SOLVER STATES & CALCULATORS
    // ==========================================
    var circuitTypeSelected by mutableStateOf("series") // "series" (توالي), "parallel" (توازي), "divider" (مقسم جهد), "stardelta" (ستار/دلتا)
    
    // Components series/parallel
    var compValue1 by mutableStateOf("10.0")
    var compValue2 by mutableStateOf("20.0")
    var compValue3 by mutableStateOf("30.0")
    var compTypeSelected by mutableStateOf("R") // "R" (أوم), "C" (ميكروفاراد), "L" (ملي هنري)
    
    var circuitResultText by mutableStateOf("أدخل القيم واضغط احسب")
    var circuitStepsText by mutableStateOf("")

    fun solveCircuit() {
        val val1 = compValue1.toDoubleOrNull() ?: 0.0
        val val2 = compValue2.toDoubleOrNull() ?: 0.0
        val val3 = compValue3.toDoubleOrNull() ?: 0.0
        val type = compTypeSelected

        if (circuitTypeSelected == "series" || circuitTypeSelected == "parallel") {
            if (val1 < 0 || val2 < 0 || val3 < 0) return
            // Count valid non-zero values
            val list = mutableListOf<Double>()
            if (val1 > 0) list.add(val1)
            if (val2 > 0) list.add(val2)
            if (val3 > 0) list.add(val3)

            if (list.isEmpty()) {
                circuitResultText = "الرجاء إدخال قيمة واحدة على الأقل أكبر من الصفر"
                return
            }

            val isSeries = circuitTypeSelected == "series"
            val unit = when(type) {
                "R" -> "أوم (Ω)"
                "C" -> "ميكروفاراد (μF)"
                else -> "ملي هنري (mH)"
            }

            if (isSeries) {
                // Series Formula
                // R or L -> Req = val1 + val2 + val3
                // C -> 1/Ceq = 1/c1 + 1/c2 + 1/c3
                if (type == "R" || type == "L") {
                    val eq = list.sum()
                    circuitResultText = "المكافئ الإجمالي (توالي): ${String.format("%.2f", eq)} $unit"
                    circuitStepsText = "خطوات التحليل خطوة بخطوة:\n" +
                            "- الدائرة متصلة على التوالي.\n" +
                            "- صيغة الحل الأساسية: Req = ${list.joinToString(" + ")}\n" +
                            "- بالتعويض المباشر: Req = ${list.sum()} $unit"
                } else {
                    // Capacitors on Series act inversely
                    val invSum = list.map { 1.0 / it }.sum()
                    val eq = 1.0 / invSum
                    circuitResultText = "المكافئ الإجمالي (توالي): ${String.format("%.2f", eq)} $unit"
                    circuitStepsText = "خطوات التحليل للمكثفات على التوالي:\n" +
                            "- المكثفات على التوالي تحسب كالتوازي للمقومات.\n" +
                            "- الصيغة: 1/Ceq = ${list.map { "1/$it" }.joinToString(" + ")}\n" +
                            "- مقلوب المجموع: Ceq = 1 / (${String.format("%.4f", invSum)}) ≈ ${String.format("%.2f", eq)} $unit"
                }
            } else {
                // Parallel Formula
                // R or L -> 1/Req = 1/r1 + 1/r2 + ...
                // C -> Ceq = c1 + c2 + c3
                if (type == "C") {
                    val eq = list.sum()
                    circuitResultText = "المكافئ الإجمالي (توازي): ${String.format("%.2f", eq)} $unit"
                    circuitStepsText = "خطوات التحليل للمكثفات على التوازي:\n" +
                            "- المكثفات على التوازي تجمع كلياً مباشرة.\n" +
                            "- الصيغة: Ceq = ${list.joinToString(" + ")}\n" +
                            "- بالتعويض: Ceq = ${list.sum()} $unit"
                } else {
                    val invSum = list.map { 1.0 / it }.sum()
                    val eq = 1.0 / invSum
                    circuitResultText = "المكافئ الإجمالي (توازي): ${String.format("%.2f", eq)} $unit"
                    circuitStepsText = "خطوات التحليل للتوازي:\n" +
                            "- صيغة الممر المتوازي: 1/Req = ${list.map { "1/$it" }.joinToString(" + ")}\n" +
                            "- مجموع المقاليب: ${String.format("%.4f", invSum)}\n" +
                            "- المقاومة المكافئة Req = 1 / المجموع = ${String.format("%.2f", eq)} $unit"
                }
            }
        } else if (circuitTypeSelected == "divider") {
            // Voltage Divider
            // input: compValue1 = Vin, compValue2 = R1, compValue3 = R2
            val vin = val1
            val r1 = val2
            val r2 = val3
            if (vin <= 0 || r1 <= 0 || r2 <= 0) {
                circuitResultText = "الرجاء إدخال قيم Vin و R1 و R2 صحيحة وأكبر من الصفر"
                return
            }
            val vout = vin * (r2 / (r1 + r2))
            circuitResultText = "جهد المخرج (Vout): ${String.format("%.2f", vout)} فولت"
            circuitStepsText = "خطوات تفكيك مقسم الجهد:\n" +
                    "- القانون المعياري: Vout = Vin × [ R2 / (R1 + R2) ]\n" +
                    "- بالتعويض بالمعطيات:\n" +
                    "  Vout = $vin × [ $r2 / ($r1 + $r2) ]\n" +
                    "  Vout = $vin × ${String.format("%.4f", r2 / (r1 + r2))}\n" +
                    "  Vout = ${String.format("%.2f", vout)} فولت.\n" +
                    "- الجهد المستهلك عبر R1 هو: ${String.format("%.2f", vin - vout)} فولت."
        } else if (circuitTypeSelected == "stardelta") {
            // Star to Delta conversion
            // input: compValue1 = R1/Ra, compValue2 = R2/Rb, compValue3 = R3/Rc (assume balanced or simple mapping)
            if (val1 <= 0 || val2 <= 0 || val3 <= 0) {
                circuitResultText = "أدخل قيم الفروع الثلاثة للمقاومات بنجمة للتحويل إلى دلتا"
                return
            }
            // Let's transform Star (R1, R2, R3) to Delta (Ra, Rb, Rc)
            // Ra = (R1*R2 + R2*R3 + R3*R1)/R1  ... Rb = .../R2 ... Rc = .../R3
            val sumProducts = (val1 * val2) + (val2 * val3) + (val3 * val1)
            val ra = sumProducts / val1
            val rb = sumProducts / val2
            val rc = sumProducts / val3

            circuitResultText = "التحويل لدلتا: Ra=${String.format("%.1f", ra)}Ω ، Rb=${String.format("%.1f", rb)}Ω ، Rc=${String.format("%.1f", rc)}Ω"
            circuitStepsText = "طريقة التحويل من نجمة (Y) إلى مثلث (Δ):\n" +
                    "- مجموع حاصل ضرب الثنائيات: (R1*R2) + (R2*R3) + (R3*R1) = $val1*$val2 + $val2*$val3 + $val1*$val3 = $sumProducts أوم.\n" +
                    "- فرع Ra المقابل للفرع 1 = المجموع / R1 = $sumProducts / $val1 = $ra أوم.\n" +
                    "- فرع Rb المقابل للفرع 2 = المجموع / R2 = $sumProducts / $val2 = $rb أوم.\n" +
                    "- فرع Rc المقابل للفرع 3 = المجموع / R3 = $sumProducts / $val3 = $rc أوم."
        }
    }


    // ==========================================
    // 3. INTERACTIVE QUIZ STATES & LOGIC
    // ==========================================
    var currentQuestionIndex by mutableStateOf(0)
    var selectedOptionIndex by mutableStateOf<Int?>(null)
    var isAnswerChecked by mutableStateOf(false)
    var correctCount by mutableStateOf(0)
    var isQuizFinished by mutableStateOf(false)

    val currentQuestion: QuizQuestion
        get() = ElectricalDataProvider.quizQuestions[currentQuestionIndex]

    fun selectOption(index: Int) {
        if (!isAnswerChecked) {
            selectedOptionIndex = index
        }
    }

    fun checkAnswer() {
        if (selectedOptionIndex != null && !isAnswerChecked) {
            isAnswerChecked = true
            if (selectedOptionIndex == currentQuestion.correctIndex) {
                correctCount++
            }
        }
    }

    fun nextQuestion() {
        if (currentQuestionIndex < ElectricalDataProvider.quizQuestions.size - 1) {
            currentQuestionIndex++
            selectedOptionIndex = null
            isAnswerChecked = false
        } else {
            isQuizFinished = true
        }
    }

    fun restartQuiz() {
        currentQuestionIndex = 0
        selectedOptionIndex = null
        isAnswerChecked = false
        correctCount = 0
        isQuizFinished = false
    }


    // ==========================================
    // 4. GEMINI AI TECHNICAL MENTOR
    // ==========================================
    var aiQuery by mutableStateOf("")
    var aiResponse by mutableStateOf("مرحباً بك يا كابتن الهندسة! أنا مستشارك الذكي المخصص للهندسة الكهربائية والآلات. اسألني أي سؤال تقني معقد كحل الشبكات وتصميم المحولات وسأجيبك فوراً بالتفاصيل الدقيقة والوحدات القياسية.")
    var isAiLoading by mutableStateOf(false)

    fun askAi(prompt: String) {
        if (prompt.isBlank() || isAiLoading) return
        isAiLoading = true
        aiResponse = "جاري التفكير وتحليل البيانات التقنية على مدار الساعة..."
        
        viewModelScope.launch {
            val response = GeminiClient.getGeminiResponse(prompt)
            aiResponse = response
            isAiLoading = false
        }
    }
}
