package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.util.Log
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.data.SavedProject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

object PdfGenerator {
    private const val TAG = "PdfGenerator"

    /**
     * Generates a PDF representing the calculation details of a project
     * and returns the Uri to share.
     */
    fun generateProjectPdf(context: Context, project: SavedProject): Uri? {
        val pdfDocument = PdfDocument()
        
        // A4 Paper Dimensions: 595 x 842
        val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        // Set up Paint objects for text layout
        val titlePaint = Paint().apply {
            color = Color.rgb(13, 71, 161) // Deep cobalt blue
            textSize = 24f
            isAntiAlias = true
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val metaPaint = Paint().apply {
            color = Color.DKGRAY
            textSize = 12f
            isAntiAlias = true
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
        }

        val sectionPaint = Paint().apply {
            color = Color.rgb(230, 81, 0) // Copper / Orange accent
            textSize = 16f
            isAntiAlias = true
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        val bodyPaint = Paint().apply {
            color = Color.BLACK
            textSize = 14f
            isAntiAlias = true
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }

        val linePaint = Paint().apply {
            color = Color.LTGRAY
            strokeWidth = 1.5f
        }

        val cardBgPaint = Paint().apply {
            color = Color.rgb(245, 245, 245)
            style = Paint.Style.FILL
        }

        // Left and Right drawing bounds
        val leftMargin = 40f
        val rightMargin = 555f
        var currentY = 50f

        // Document Title Block
        canvas.drawText("تقرير حسابات هندسية كهربائية", rightMargin - 300f, currentY, titlePaint)
        currentY += 15f
        canvas.drawLine(leftMargin, currentY, rightMargin, currentY, linePaint)
        currentY += 25f

        // Meta Data (Date and category)
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
        val dateString = dateFormat.format(Date(project.date))
        canvas.drawText("التصنيف: ${project.category}", rightMargin - 150f, currentY, metaPaint)
        canvas.drawText("تاريخ الحساب: $dateString", leftMargin, currentY, metaPaint)
        currentY += 35f

        // Project Title Card
        canvas.drawRect(leftMargin, currentY - 5f, rightMargin, currentY + 35f, cardBgPaint)
        canvas.drawText(project.title, rightMargin - 280f, currentY + 22f, sectionPaint)
        currentY += 60f

        // Section: Summary of results
        canvas.drawText("ملخص النتائج الأساسية :", rightMargin - 180f, currentY, sectionPaint)
        currentY += 25f

        // Split summary by line or display it clearly
        val summaries = project.summary.split("\n", "؛")
        for (sumLine in summaries) {
            if (sumLine.trim().isNotEmpty()) {
                canvas.drawText(sumLine.trim(), rightMargin - 350f, currentY, bodyPaint)
                currentY += 22f
            }
        }
        currentY += 15f
        canvas.drawLine(leftMargin, currentY, rightMargin, currentY, linePaint)
        currentY += 25f

        // Section: Technical Details and steps
        canvas.drawText("خطوات الحل والبيانات الفنية :", rightMargin - 180f, currentY, sectionPaint)
        currentY += 25f

        val detailsLines = project.details.split("\n")
        var pageNum = 1
        for (line in detailsLines) {
            if (line.trim().isNotEmpty()) {
                // Wrap text if too long or just draw lines safely
                val words = line.trim()
                if (currentY > 780f) {
                    // Start new PDF page if exceeded limit
                    pdfDocument.finishPage(page)
                    pageNum++
                    val nextPage = pdfDocument.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNum).create())
                    val nextCanvas = nextPage.canvas
                    currentY = 50f
                    // Redraw header on new page
                    nextCanvas.drawText("تقرير حسابات - صفحة $pageNum", leftMargin, currentY, metaPaint)
                    currentY += 20f
                    nextCanvas.drawLine(leftMargin, currentY, rightMargin, currentY, linePaint)
                    currentY += 30f
                }
                
                // Draw text right-aligned for Arabic support or standard left aligned for technical lines
                if (words.contains("=") || words.startsWith("I ") || words.startsWith("V ") || words.startsWith("R ")) {
                    canvas.drawText(words, leftMargin + 10f, currentY, bodyPaint)
                } else {
                    canvas.drawText(words, rightMargin - 450f, currentY, bodyPaint)
                }
                currentY += 24f
            }
        }

        // Add page footer with support signatures
        currentY = 810f
        canvas.drawLine(leftMargin, currentY, rightMargin, currentY, linePaint)
        canvas.drawText("مساعد مهندس الكهرباء الشامل - نظام ذكي وموثوق للعمل الميداني", leftMargin, currentY + 18f, metaPaint)

        pdfDocument.finishPage(page)

        // Save generated PDF into cache directory
        val cachePath = File(context.cacheDir, "shared_files")
        if (!cachePath.exists()) {
            cachePath.mkdirs()
        }
        
        // Sanitize title for filename
        val sanitizedTitle = project.title.replace(Regex("[^a-zA-Z0-9أ-ي]"), "_")
        val pdfFile = File(cachePath, "ELEC_REPORT_${sanitizedTitle}_${project.id}.pdf")
        
        return try {
            val fileOutputStream = FileOutputStream(pdfFile)
            pdfDocument.writeTo(fileOutputStream)
            pdfDocument.close()
            fileOutputStream.close()
            
            // Get content Uri through FileProvider (Crucial for secure Android sharing)
            FileProvider.getUriForFile(context, "com.example.fileprovider", pdfFile)
        } catch (e: Exception) {
            Log.e(TAG, "Error writing PDF: ", e)
            pdfDocument.close()
            null
        }
    }

    /**
     * Launches the Android Share Sheet allowing users to seamlessly transmit
     * the generated PDF to Email, WhatsApp, Telegram, etc.
     */
    fun sharePdf(context: Context, pdfUri: Uri, title: String) {
        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, pdfUri)
            putExtra(Intent.EXTRA_SUBJECT, "تقرير حسابات كهربائية: $title")
            putExtra(Intent.EXTRA_TEXT, "مرحباً، مرفق لكم تقرير الحسابات الهندسية لـ '$title' بصيغة PDF ومولد بالكامل عبر تطبيق مساعد مهندس الكهرباء الشامل.")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        
        val chooserIntent = Intent.createChooser(shareIntent, "مشاركة تقرير الحسابات عبر (PDF):")
        chooserIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            context.startActivity(chooserIntent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start sharing chooser", e)
            Toast.makeText(context, "عذراً، فشلت عملية تمكين المشاركة مع تطبيقات التواصل.", Toast.LENGTH_SHORT).show()
        }
    }
}
