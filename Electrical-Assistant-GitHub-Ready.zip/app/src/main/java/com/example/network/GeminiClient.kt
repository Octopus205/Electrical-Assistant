package com.example.network

import android.util.Log
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiClient {
    private const val TAG = "GeminiClient"
    
    // Configured with generous 60s timeouts as recommended by the gemini-api skill
    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    private const val SYSTEM_INSTRUCTION = 
        "أنت مهندس ومستشار كهربائي فني محترف ومساعد ذكي للطلاب والخريجين والفنيين. " +
        "أجب دائماً باللغة العربية بدقة هندسية عالية وبأسلوب منظم وواضح. " +
        "استخدم القوانين الكهربائية والرياضية المناسبة، واشرح الحل خطوة بخطوة عند الضرورة، " +
        "واكتب الوحدات الكهربائية للمخرجات (مثل فولت، أمبير، أوم، واط، فاراد) بوضوح."

    suspend fun getGeminiResponse(prompt: String): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY

        // Check if API key is not configured or is placeholder
        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY" || apiKey.contains("PLACEHOLDER")) {
            return@withContext "⚠️ لم يتم تكوين مفتاح Gemini API بشكل صحيح.\n\n" +
                    "يرجى الانتقال إلى لوحة الأسرار (Secrets panel) في Google AI Studio، " +
                    "وإدخال مفتاح GEMINI_API_KEY الخاص بك لتفعيل كافة مميزات المساعد الذكي للإجابة عن أسئلتك التقنية وحل المشكلات الهندسية."
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
        
        try {
            // Build the JSON body manually using native org.json
            val requestBodyJson = JSONObject().apply {
                // "contents" array
                val contentsArray = JSONArray().apply {
                    val contentObj = JSONObject().apply {
                        val partsArray = JSONArray().apply {
                            val partObj = JSONObject().apply {
                                put("text", prompt)
                            }
                            put(partObj)
                        }
                        put("parts", partsArray)
                    }
                    put(contentObj)
                }
                put("contents", contentsArray)

                // "systemInstruction"
                val sysInstObj = JSONObject().apply {
                    val partsArray = JSONArray().apply {
                        val partObj = JSONObject().apply {
                            put("text", SYSTEM_INSTRUCTION)
                        }
                        put(partObj)
                    }
                    put("parts", partsArray)
                }
                put("systemInstruction", sysInstObj)
                
                // "generationConfig"
                val genConfigObj = JSONObject().apply {
                    put("temperature", 0.7)
                }
                put("generationConfig", genConfigObj)
            }

            val mediaType = "application/json; charset=utf-8".toMediaType()
            val body = requestBodyJson.toString().toRequestBody(mediaType)
            
            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                val responseStr = response.body?.string() ?: ""
                if (!response.isSuccessful) {
                    Log.e(TAG, "Unsuccessful response: $responseStr")
                    return@withContext "⚠️ حدث خطأ أثناء الاتصال بخوادم الذكاء الاصطناعي: رمز ${response.code}"
                }

                // Parse the response manually to extract the text safely
                val responseJson = JSONObject(responseStr)
                val candidates = responseJson.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val firstCandidate = candidates.getJSONObject(0)
                    val content = firstCandidate.optJSONObject("content")
                    if (content != null) {
                        val parts = content.optJSONArray("parts")
                        if (parts != null && parts.length() > 0) {
                            return@withContext parts.getJSONObject(0).optString("text", "لا يوجد نص في الإجابة.")
                        }
                    }
                }
                
                return@withContext "⚠️ لم يتوفر رد مناسب من الذكاء الاصطناعي، يرجى المحاولة مرة أخرى."
            }
        } catch (e: Exception) {
            Log.e(TAG, "Connection Exception: ", e)
            return@withContext "⚠️ فشل في الاتصال بالشبكة. يرجى التحقق من اتصالك بالإنترنت والتحقق من صلاحية مفتاح الـ API الخاص بك.\nتفاصيل الخطأ: ${e.localizedMessage}"
        }
    }
}
