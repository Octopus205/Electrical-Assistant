package com.example

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.SavedProject
import com.example.models.ElectricalDataProvider
import com.example.models.ElectricalSymbol
import com.example.models.SymbolDrawType
import com.example.ui.ElectricalViewModel
import com.example.ui.components.ElectricalSymbolVisual
import com.example.ui.theme.*
import com.example.util.PdfGenerator

// Language helper extension helper
fun Boolean.t(ar: String, en: String): String = if (this) ar else en

// Translates reports and engineering step guides on the fly from Arabic templates to standard English
fun translateReport(report: String, isArabic: Boolean): String {
    if (isArabic) return report
    return report
        .replace("المعطيات وتحليل النتائج:", "Given Data & Results Analysis:")
        .replace("لقرأة حمل قدرته", "For load of capacity")
        .replace("كيلو واط، بتيار مسحوب مقداره", "kW, with drawn current of")
        .replace("أمبير.", "A.")
        .replace("المقطع النحاسي الآمن الموصى به:", "Recommended safe copper wire section:")
        .replace("مم².", "mm².")
        .replace("فولت، بنسبة", "V, and a ratio of")
        .replace("وهو ضمن المسموح المعياري (أقل من", "which is within standard limits (less than")
        .replace("يتجاوز النسبة المعيارية، ولكنه أكبر حجم سلك بالمنظومة للوقاية.", "exceeds standard ratio, but it represents the maximum system wire size for safety.")
        .replace("هبوط الجهد الحاصل هو", "Target voltage drop calculated is")
        .replace("نتائج تحليل هبوط الجهد:", "Voltage Drop Analysis Results:")
        .replace("قيمة الهبوط الفعلي:", "Actual voltage drop value:")
        .replace("فولت.", "V.")
        .replace("نسبة الهبوط:", "Voltage drop percentage:")
        .replace("من جهد المصدر الأصلي.", "of initial source voltage.")
        .replace("مقاومة الخط الإجمالية:", "Total line resistance:")
        .replace("أوم.", "Ohms.")
        .replace("حالة الجهد عند نهاية الخط:", "Output voltage at line end:")
        .replace("تحليل تيار الحمل الكامل للمحرك (FLA):", "Motor Full Load Current (FLA) Analysis:")
        .replace("تيار التشغيل المقنن:", "Operating rated current:")
        .replace("تيار الإقلاع المتوقع (Direct Online):", "Expected inrush current (Direct Online):")
        .replace("أمبير (بمتوسط 6.5 أضعاف).", "A (average of 6.5 times).")
        .replace("تيار إقلاع بنظام ستار-دلتا مقترح:", "Proposed Star-Delta starter current:")
        .replace("خطة تحسين جودة الطاقة ومعامل القدرة:", "Power Factor & Energy Quality Correction Plan:")
        .replace("سعة بنك المكثفات المطلوبة:", "Required capacitor bank capacity:")
        .replace("كيلو فار (kVAr).", "kVAr.")
        .replace("سعة كل مكثف بالدلتا/ستار:", "Capacity of each star/delta capacitor:")
        .replace("ميكروفاراد (μF).", "uF.")
        .replace("توفير فاقد التيار المتوقع: تقليل التيار المغذي الإجمالي بنسبة تقارب", "Expected active power reduction: decreasing line feeding current by approx")
        .replace("مما يرشّد الكابلات.", "maximizing cable conservation.")
        .replace("خطأ في المدخلات الرياضية للزاوية الجيبية المتناظرة.", "Mathematical entry error for cosine arcsin conversions.")
        .replace("أدخل القيم واضغط احسب", "Enter values and hit Calculate")
        .replace("الرجاء إدخال قيمة واحدة على الأقل أكبر من الصفر", "Please input at least one value greater than zero")
        .replace("المكافئ الإجمالي (توالي):", "Total Equivalent (Series):")
        .replace("المكافئ الإجمالي (توازي):", "Total Equivalent (Parallel):")
        .replace("خطوات التحليل خطوة بخطوة:", "Step-by-step solving path:")
        .replace("الدائرة متصلة على التوالي.", "The circuit is connected in Series.")
        .replace("صيغة الحل الأساسية:", "Primary formula for solution:")
        .replace("بالتعويض المباشر:", "By direct substitution:")
        .replace("خطوات التحليل للمكثفات على التوالي:", "Series analysis steps for Capacitors:")
        .replace("المكثفات على التوالي تحسب كالتوازي للمقومات.", "Capacitors in series are computed like resistors in parallel.")
        .replace("مقلوب المجموع:", "Reciprocal of sum:")
        .replace("المكثفات على التوازي تجمع كلياً مباشرة.", "Capacitors in parallel are added directly together.")
        .replace("بالتعويض:", "By substitution:")
        .replace("مكعب الحل الهندسي المعتمد:", "Approved Engineering Solving Steps:")
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            // Explicit togglable state for dark reading mode, perfect for on-field electrical panel rooms
            var darkReadingMode by rememberSaveable { mutableStateOf(true) }
            var isArabic by rememberSaveable { mutableStateOf(true) }

            MyApplicationTheme(darkTheme = darkReadingMode, dynamicColor = false) {
                // Ensure RTL layout support for complete Arabic experience, LTR for English
                val layoutDirection = if (isArabic) LayoutDirection.Rtl else LayoutDirection.Ltr
                CompositionLocalProvider(LocalLayoutDirection provides layoutDirection) {
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        ElectricalAppMain(
                            darkReadingMode = darkReadingMode,
                            onToggleTheme = { darkReadingMode = !darkReadingMode },
                            isArabic = isArabic,
                            onToggleLanguage = { isArabic = !isArabic }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ElectricalAppMain(
    darkReadingMode: Boolean,
    onToggleTheme: () -> Unit,
    isArabic: Boolean,
    onToggleLanguage: () -> Unit,
    viewModel: ElectricalViewModel = viewModel()
) {
    var activeTab by rememberSaveable { mutableStateOf("dashboard") }
    
    // Core Scaffold wrapping the views safely
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(PrimaryPurple),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = imageName("bolt"),
                                contentDescription = if (isArabic) "شارة الشحنة" else "Charge Icon",
                                tint = OnPrimaryPurple,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = if (isArabic) "مساعد المهندس" else "Engineer Companion",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp,
                            color = OnAppSurface
                        )
                    }
                },
                actions = {
                    // Language Switch Button
                    TextButton(
                        onClick = onToggleLanguage,
                        modifier = Modifier.testTag("language_toggle_button")
                    ) {
                        Text(
                            text = if (isArabic) "English" else "العربية",
                            color = PrimaryPurple,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                    // Theme Switch Button
                    IconButton(
                        onClick = onToggleTheme,
                        modifier = Modifier.testTag("theme_toggle_button")
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (darkReadingMode) Color(0xFF332D41) else Color(0xFFEADDFF)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (darkReadingMode) {
                                Text("🌙", fontSize = 16.sp)
                            } else {
                                Text("☀️", fontSize = 16.sp)
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = AppBackground
                )
            )
        },
        bottomBar = {
            NavigationBar(
                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars),
                containerColor = AppSurface,
                tonalElevation = 0.dp
            ) {
                val items = listOf(
                    Triple("dashboard", if (isArabic) "الرئيسية" else "Home", Icons.Default.Home),
                    Triple("calculators", if (isArabic) "الحاسبات" else "Calculators", Icons.Default.List),
                    Triple("library", if (isArabic) "المصطلحات" else "Glossary", Icons.Default.Search),
                    Triple("quiz", if (isArabic) "الاختبارات" else "Quizzes", Icons.Default.Star),
                    Triple("ai", if (isArabic) "المستشار الذكي" else "AI Advisor", Icons.Default.Info)
                )

                items.forEach { (tab, label, icon) ->
                    NavigationBarItem(
                        selected = activeTab == tab,
                        onClick = { activeTab = tab },
                        icon = { Icon(imageVector = icon, contentDescription = label) },
                        label = { Text(text = label, maxLines = 1, fontSize = 11.sp, fontWeight = if (activeTab == tab) FontWeight.Bold else FontWeight.Medium) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = PrimaryPurple,
                            selectedTextColor = PrimaryPurple,
                            indicatorColor = PrimaryContainerPurple,
                            unselectedIconColor = OnAppSurface.copy(alpha = 0.6f),
                            unselectedTextColor = OnAppSurface.copy(alpha = 0.6f)
                        ),
                        modifier = Modifier.testTag("nav_tab_$tab")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (activeTab) {
                "dashboard" -> DashboardScreen(isArabic = isArabic, onNavigateToTab = { activeTab = it }, viewModel = viewModel)
                "calculators" -> CalculatorsScreen(isArabic = isArabic, viewModel = viewModel)
                "library" -> LibraryScreen(isArabic = isArabic)
                "quiz" -> QuizScreen(isArabic = isArabic, viewModel = viewModel)
                "ai" -> AiAssistantScreen(isArabic = isArabic, viewModel = viewModel)
            }
        }
    }
}

// -------------------------------------------------------------
// 1. DASHBOARD VIEW DEFINITION
// -------------------------------------------------------------
@Composable
fun DashboardScreen(
    isArabic: Boolean,
    onNavigateToTab: (String) -> Unit,
    viewModel: ElectricalViewModel
) {
    val savedProjects by viewModel.savedProjects.collectAsState()
    
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome Header card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Column(
                    modifier = Modifier.padding(18.dp)
                ) {
                    Text(
                        text = isArabic.t("مرحباً بك يا مهندس بالعمل الميداني!", "Welcome, Engineer, to the Field Work!"),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = isArabic.t("هنا دليلك وقاعدتك الحسابية المتكاملة لحل الدوائر، تقييم مقاطع الأسلاك ومشاكل شبكات التوصيل على الفور وبأعلى دقة للمهندسين والطلاب.", "Here is your handbook and integrated calculator suite for solving circuits, sizing cables, and troubleshooting power network concerns immediately with high field accuracy."),
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f),
                        lineHeight = 22.sp
                    )
                }
            }
        }

        // Daily On-field Tip card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Row(
                    modifier = Modifier
                        .padding(16.dp)
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFFE65100).copy(alpha = 0.1f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = isArabic.t("نصيحة", "Tip"),
                            tint = Color(0xFFE65100)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = isArabic.t("نصيحة اليوم الهندسية:", "Today's Engineering Tip:"),
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFE65100),
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = isArabic.t("تأكد دائماً من موازنة الأحمال على الأطوار الثلاثة (Star) لمنع تدفق تيار عالي في سلك التعادل (النيوترال)، وحماية الأجهزة من الاحتراق.", "Always balance the electrical loads across all three phases (Star connection) to prevent excessive neutral current, protecting equipment from severe hazards."),
                            fontSize = 13.sp,
                            lineHeight = 18.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Quick Modules Redirection Header
        item {
            Text(
                text = isArabic.t("الأقسام والخدمات السريعة", "Quick Services & Tools"),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        // Standard Grid options (Calculators, symbols, quizzes, AI help)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                DashboardGridItem(
                    title = isArabic.t("حاسبة الدوائر", "Circuit Calc"),
                    sub = isArabic.t("حل خطوة بخطوة لمقاطع السلك والدوائر", "Step-by-step wire & circuit solver"),
                    icon = Icons.Default.List,
                    containerColor = BerryDark,
                    borderColor = BorderOutlineVariant,
                    iconBgColor = BerryLight,
                    iconTextColor = BerryDark,
                    titleColor = BerryLight,
                    subColor = Color(0xFFF9DEDC),
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateToTab("calculators") }
                )
                DashboardGridItem(
                    title = isArabic.t("المعادلات", "Formulas"),
                    sub = isArabic.t("أكثر من 500 قانون ومستشار ذكي متكامل", "Over 500 equations & smart AI mentor"),
                    icon = Icons.Default.Info,
                    containerColor = VioletDark,
                    borderColor = BorderOutlineVariant,
                    iconBgColor = OnPrimaryContainerPurple,
                    iconTextColor = OnPrimaryPurple,
                    titleColor = OnPrimaryContainerPurple,
                    subColor = OnAppSurface.copy(alpha = 0.7f),
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateToTab("ai") }
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                DashboardGridItem(
                    title = isArabic.t("المصطلحات", "Glossary"),
                    sub = isArabic.t("الرموز والمعايير والقاموس التقني", "Symbols, standards & dictionary"),
                    icon = Icons.Default.Search,
                    containerColor = VioletDark,
                    borderColor = BorderOutlineVariant,
                    iconBgColor = TertiaryBlue,
                    iconTextColor = OnTertiaryBlue,
                    titleColor = TertiaryBlue,
                    subColor = Color(0xFFE1E2EC),
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateToTab("library") }
                )
                DashboardGridItem(
                    title = isArabic.t("الاختبارات", "Quizzes"),
                    sub = isArabic.t("قيم معلوماتك وحفظ تقدمك فوراً", "Evaluate your skills & see scores"),
                    icon = Icons.Default.Star,
                    containerColor = GreenDark,
                    borderColor = BorderOutlineVariant,
                    iconBgColor = GreenLight,
                    iconTextColor = Color(0xFF072100),
                    titleColor = GreenLight,
                    subColor = Color(0xFFD9E6D8),
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateToTab("quiz") }
                )
            }
        }

        // Saved Records history title
        item {
            Text(
                text = isArabic.t("حساباتك الهندسية الأخيرة (${savedProjects.size})", "Your Recent Engineering Calculations (${savedProjects.size})"),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        if (savedProjects.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = isArabic.t("قائمة فارغة", "Empty list"),
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = isArabic.t("لا توجد مشاريع أو حسابات محفوظة بعد الميدان.\nاحسب أي معامل وسجل لحفظه هنا.", "No saved calculations or projects in record.\nCalculate parameters and press Save to see them here."),
                            textAlign = TextAlign.Center,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    }
                }
            }
        } else {
            // Display saved project items
            items(savedProjects.take(4)) { project ->
                SavedProjectListItem(
                    isArabic = isArabic,
                    project = project,
                    onDelete = { viewModel.deleteProject(project.id) },
                    onSharePdf = { context ->
                        val uri = PdfGenerator.generateProjectPdf(context, project)
                        if (uri != null) {
                            PdfGenerator.sharePdf(context, uri, project.title)
                        } else {
                            Toast.makeText(context, isArabic.t("فشل توليد التقرير المكتوب كـ PDF", "Failed to compile written report as PDF"), Toast.LENGTH_SHORT).show()
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun DashboardGridItem(
    title: String,
    sub: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    containerColor: Color,
    borderColor: Color,
    iconBgColor: Color,
    iconTextColor: Color,
    titleColor: Color,
    subColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .height(142.dp)
            .clip(RoundedCornerShape(28.dp))
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(
            containerColor = containerColor
        ),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Column(
            modifier = Modifier
                .padding(14.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(iconBgColor),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = title, tint = iconTextColor)
            }
            Column {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = titleColor
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = sub,
                    fontSize = 11.sp,
                    color = subColor,
                    maxLines = 2,
                    lineHeight = 14.sp
                )
            }
        }
    }
}

// Helper to determine bolt vector icon safely
private fun imageName(name: String): androidx.compose.ui.graphics.vector.ImageVector {
    return Icons.Default.PlayArrow
}


// -------------------------------------------------------------
// 2. CALCULATORS VIEW DEFINITION
// -------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalculatorsScreen(isArabic: Boolean, viewModel: ElectricalViewModel) {
    var subTabSelected by rememberSaveable { mutableStateOf("wire") }
    val context = LocalContext.current

    Column(modifier = Modifier.fillMaxSize()) {
        // Tab row for selection
        ScrollableTabRow(
            selectedTabIndex = when(subTabSelected) {
                "wire" -> 0
                "drop" -> 1
                "motor" -> 2
                "pf" -> 3
                else -> 4
            },
            edgePadding = 12.dp
        ) {
            Tab(selected = subTabSelected == "wire", onClick = { subTabSelected = "wire" }, text = { Text(isArabic.t("مقطع السلك", "Wire Sizing")) })
            Tab(selected = subTabSelected == "drop", onClick = { subTabSelected = "drop" }, text = { Text(isArabic.t("هبوط الجهد", "Voltage Drop")) })
            Tab(selected = subTabSelected == "motor", onClick = { subTabSelected = "motor" }, text = { Text(isArabic.t("تيار المحرك", "Motor FLA")) })
            Tab(selected = subTabSelected == "pf", onClick = { subTabSelected = "pf" }, text = { Text(isArabic.t("تحسين المعامل", "Power Factor")) })
            Tab(selected = subTabSelected == "circuits", onClick = { subTabSelected = "circuits" }, text = { Text(isArabic.t("حلال الدوائر", "Circuit Solver")) })
        }

        // Sub View Switch
        Box(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            when (subTabSelected) {
                "wire" -> WireSizerSubScreen(isArabic, viewModel, context)
                "drop" -> VoltageDropSubScreen(isArabic, viewModel, context)
                "motor" -> MotorFlaSubScreen(isArabic, viewModel, context)
                "pf" -> PowerFactorCorrectionSubScreen(isArabic, viewModel, context)
                "circuits" -> SmartCircuitSubScreen(isArabic, viewModel, context)
            }
        }
    }
}

@Composable
fun WireSizerSubScreen(isArabic: Boolean, viewModel: ElectricalViewModel, context: Context) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(text = isArabic.t("حساب واختيار مقطع الكابل النحاسي المناسب", "Compute & Select Safe Copper Cable Sizing"), fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(text = isArabic.t("يقوم بحساب التيار وسعة الكابل المعيارية وتدقيق هبوط الجهد الإجمالي واختيار أكفأ مقطع وفق المعايير العالمية.", "Calculates exact working currents, standard ampacity, verifies cumulative voltage drops, and proposes the most efficient copper section."), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

        OutlinedTextField(
            value = viewModel.wsPowerKw,
            onValueChange = { viewModel.wsPowerKw = it },
            label = { Text(isArabic.t("القدرة الإجمالية للأحمال (كيلو واط KW)", "Total Load Active Power (kW)")) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth().testTag("ws_power_input")
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = viewModel.wsVoltage,
                onValueChange = { viewModel.wsVoltage = it },
                label = { Text(isArabic.t("الجهد الكهربائي (فولت V)", "Voltage (V)")) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f).testTag("ws_voltage_input")
            )
            OutlinedTextField(
                value = viewModel.wsPowerFactor,
                onValueChange = { viewModel.wsPowerFactor = it },
                label = { Text(isArabic.t("معامل القدرة (PF)", "Power Factor (PF)")) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f).testTag("ws_pf_input")
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = viewModel.wsLengthMeters,
                onValueChange = { viewModel.wsLengthMeters = it },
                label = { Text(isArabic.t("طول الخط (متر m)", "Line Length (m)")) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f).testTag("ws_length_input")
            )
            OutlinedTextField(
                value = viewModel.wsMaxDropPct,
                onValueChange = { viewModel.wsMaxDropPct = it },
                label = { Text(isArabic.t("أقصى هبوط مسموح %", "Max Allowed Drop %")) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f).testTag("ws_drop_limit_input")
            )
        }

        // Phase selection Switch
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = isArabic.t("المصدر ثلاثي الأطوار (3-Phase / 380V)", "Three-Phase Supply (3-Phase / 380V)"), modifier = Modifier.weight(1f))
            Switch(
                checked = viewModel.wsIsThreePhase,
                onCheckedChange = { viewModel.wsIsThreePhase = it },
                modifier = Modifier.testTag("ws_phase_switch")
            )
        }

        Button(
            onClick = { viewModel.calculateWireSize() },
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("ws_calc_button")
        ) {
            Text(isArabic.t("احلّل الحمل الفني وأقترح حجم السلك", "Analyze Load & Suggest Wire Size"), fontWeight = FontWeight.Bold)
        }

        // Results Card representation
        if (viewModel.wsResultCurrent > 0) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (viewModel.wsResultIsSafe) Color(0xFF1B5E20).copy(alpha = 0.08f) else Color(0xFFB71C1C).copy(alpha = 0.08f)
                ),
                border = BorderStroke(1.dp, if (viewModel.wsResultIsSafe) Color(0xFF2E7D32) else Color(0xFFC62828))
            ) {
                Column(modifier = Modifier.padding(16.dp).fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = isArabic.t("النتائج وقرار الاختيار الحجمي:", "Results & Selection Summary:"),
                            fontWeight = FontWeight.Bold,
                            color = if (viewModel.wsResultIsSafe) Color(0xFF2E7D32) else Color(0xFFC62828)
                        )
                        IconButton(
                            onClick = {
                                viewModel.saveProject(
                                    title = isArabic.t("حساب سلك كابل " + viewModel.wsPowerKw + "kW على مسافة " + viewModel.wsLengthMeters + "م", "Cable size calculation " + viewModel.wsPowerKw + "kW at " + viewModel.wsLengthMeters + "m"),
                                    category = isArabic.t("حاسبة الأسلاك", "Cable Calculator"),
                                    summary = isArabic.t("تيار: ${String.format("%.1f", viewModel.wsResultCurrent)}A؛ مقطع مقترح: ${viewModel.wsResultSize}مم²؛ هبوط: ${String.format("%.2f", viewModel.wsResultDropPct)}%", "Current: ${String.format("%.1f", viewModel.wsResultCurrent)}A; Propose: ${viewModel.wsResultSize}mm²; Drop: ${String.format("%.2f", viewModel.wsResultDropPct)}%"),
                                    details = translateReport(viewModel.wsResultReport, isArabic)
                                )
                                Toast.makeText(context, isArabic.t("تم حفظ المشروع ومسار الحساب كقيد للرجوع الميداني!", "Project saved to workspace successfully!"), Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.testTag("ws_save_button")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = isArabic.t("حفظ القيد بالدليل", "Save Record"), tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = isArabic.t("تيار الحمل المستمر: ${String.format("%.2f", viewModel.wsResultCurrent)} أمبير", "Continuous Load Current: ${String.format("%.2f", viewModel.wsResultCurrent)} Amps"), fontSize = 15.sp, fontWeight = FontWeight.Medium)
                    Text(text = isArabic.t("المقطع النحاسي المثالي: ${viewModel.wsResultSize} مم²", "Ideal Copper Area: ${viewModel.wsResultSize} mm²"), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(text = isArabic.t("هبوط الجهد الإجمالي: ${String.format("%.2f", viewModel.wsResultDropVolts)} فولت (${String.format("%.2f", viewModel.wsResultDropPct)}%)", "Total Voltage Drop: ${String.format("%.2f", viewModel.wsResultDropVolts)} V (${String.format("%.2f", viewModel.wsResultDropPct)}%)"), fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = translateReport(viewModel.wsResultReport, isArabic),
                        fontSize = 12.sp,
                        lineHeight = 17.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun VoltageDropSubScreen(isArabic: Boolean, viewModel: ElectricalViewModel, context: Context) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(text = isArabic.t("حساب هبوط وفقدان الجهد الكهربائي بالمسافة", "Calculate Voltage Drop & Cable Losses"), fontWeight = FontWeight.Bold, fontSize = 16.sp)

        OutlinedTextField(
            value = viewModel.vdCurrent,
            onValueChange = { viewModel.vdCurrent = it },
            label = { Text(isArabic.t("شدة تيار الحمل الفعلي (أمبير A)", "Active Load Current (Amps A)")) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth().testTag("vd_current_input")
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = viewModel.vdLen,
                onValueChange = { viewModel.vdLen = it },
                label = { Text(isArabic.t("المسافة الكلية (متر m)", "Total Distance (m)")) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f).testTag("vd_length_input")
            )
            OutlinedTextField(
                value = viewModel.vdArea,
                onValueChange = { viewModel.vdArea = it },
                label = { Text(isArabic.t("مقطع السلك الحالي (مم²)", "Current Wire Area (mm²)")) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f).testTag("vd_area_input")
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = viewModel.vdVoltage,
                onValueChange = { viewModel.vdVoltage = it },
                label = { Text(isArabic.t("فولتية المصدر (فولت V)", "Source Voltage (V)")) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f).testTag("vd_voltage_input")
            )
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = isArabic.t("أطوار 3 فاز", "3-Phase"), fontSize = 12.sp)
                Spacer(modifier = Modifier.width(4.dp))
                Switch(
                    checked = viewModel.vdIsThreePhase,
                    onCheckedChange = { viewModel.vdIsThreePhase = it },
                    modifier = Modifier.testTag("vd_phase_switch")
                )
            }
        }

        Button(
            onClick = { viewModel.calculateVoltageDropOnly() },
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("vd_calc_button")
        ) {
            Text(isArabic.t("احسب هبوط الجهد", "Calculate Voltage Drop"), fontWeight = FontWeight.Bold)
        }

        if (viewModel.vdResultDropVolts > 0) {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp).fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = isArabic.t("تقرير هبوط الجهد الفعلي:", "Actual Voltage Drop Report:"), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        IconButton(
                            onClick = {
                                viewModel.saveProject(
                                    title = isArabic.t("فحص هبوط جهد كابل " + viewModel.vdArea + "مم² بتيار " + viewModel.vdCurrent + " أمبير", "Voltage drop test of " + viewModel.vdArea + "mm² cable at " + viewModel.vdCurrent + " A"),
                                    category = isArabic.t("هبوط الجهد", "Voltage Drop"),
                                    summary = isArabic.t("هبوط الجهد: ${String.format("%.2f", viewModel.vdResultDropVolts)} فولت؛ نسبة: ${String.format("%.2f", viewModel.vdResultDropPct)}%", "Drop: ${String.format("%.2f", viewModel.vdResultDropVolts)} V; Ratio: ${String.format("%.2f", viewModel.vdResultDropPct)}%"),
                                    details = translateReport(viewModel.vdReport, isArabic)
                                )
                                Toast.makeText(context, isArabic.t("تم حفظ نتيجة الفقد وقوانينها!", "Voltage drop calculation saved successfully!"), Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.testTag("vd_save_button")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = isArabic.t("حفظ", "Save"))
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = isArabic.t("الهبوط الفعلي المقاس: ${String.format("%.2f", viewModel.vdResultDropVolts)} فولت", "Actual Measured Drop: ${String.format("%.2f", viewModel.vdResultDropVolts)} Volts"), fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text(text = isArabic.t("نسبة الفقد المقدرة: ${String.format("%.2f", viewModel.vdResultDropPct)}%", "Estimated Drop Ratio: ${String.format("%.2f", viewModel.vdResultDropPct)}%"), fontSize = 15.sp, color = if (viewModel.vdResultDropPct > 3.0) Color(0xFFC62828) else Color(0xFF2E7D32))
                    Spacer(modifier = Modifier.height(6.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = translateReport(viewModel.vdReport, isArabic), fontSize = 12.sp, lineHeight = 17.sp)
                }
            }
        }
    }
}

@Composable
fun MotorFlaSubScreen(isArabic: Boolean, viewModel: ElectricalViewModel, context: Context) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(text = isArabic.t("حساب تيار محرك ومواصفات حماية الإقلاع", "Calculate Motor FLA & Starter Protection"), fontWeight = FontWeight.Bold, fontSize = 16.sp)

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = viewModel.mtPower,
                onValueChange = { viewModel.mtPower = it },
                label = { Text(isArabic.t("قيمة قدرة المحرك", "Motor Rated Power")) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f).testTag("mt_power_input")
            )
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(text = if (viewModel.mtPowerUnitHp) isArabic.t("حصان (HP)", "Horsepower (HP)") else isArabic.t("كيلوواط (kW)", "Kilowatts (kW)"), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.width(4.dp))
                Switch(
                    checked = viewModel.mtPowerUnitHp,
                    onCheckedChange = { viewModel.mtPowerUnitHp = it },
                    modifier = Modifier.testTag("mt_unit_switch")
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = viewModel.mtVoltage,
                onValueChange = { viewModel.mtVoltage = it },
                label = { Text(isArabic.t("جهد التوصيل فولت", "Voltage (V)")) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f).testTag("mt_voltage_input")
            )
            OutlinedTextField(
                value = viewModel.mtEfficiency,
                onValueChange = { viewModel.mtEfficiency = it },
                label = { Text(isArabic.t("الكفاءة المقدرة (%)", "Efficiency (%)")) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f).testTag("mt_eff_input")
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = viewModel.mtPowerFactor,
                onValueChange = { viewModel.mtPowerFactor = it },
                label = { Text(isArabic.t("معامل القدرة (cos φ)", "Power Factor (cos φ)")) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f).testTag("mt_pf_input")
            )
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = isArabic.t("محرك 3 فاز", "3-Phase Motor"), fontSize = 12.sp)
                Spacer(modifier = Modifier.width(4.dp))
                Switch(
                    checked = viewModel.mtIsThreePhase,
                    onCheckedChange = { viewModel.mtIsThreePhase = it },
                    modifier = Modifier.testTag("mt_phase_switch")
                )
            }
        }

        Button(
            onClick = { viewModel.calculateMotorFla() },
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("mt_calc_button")
        ) {
            Text(isArabic.t("احسب التيار والحماية", "Calculate FLA & Protection"), fontWeight = FontWeight.Bold)
        }

        if (viewModel.mtResultAmps > 0) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp).fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = isArabic.t("التيار الإسمي للمحرك (FLA):", "Motor Nominal Current (FLA):"), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        IconButton(
                            onClick = {
                                val labelUnit = if (viewModel.mtPowerUnitHp) isArabic.t("حصان", "HP") else isArabic.t("كيلوواط", "kW")
                                viewModel.saveProject(
                                    title = isArabic.t("محاسبة محرك بقيمة " + viewModel.mtPower + " " + labelUnit, "Motor calculations for " + viewModel.mtPower + " " + labelUnit),
                                    category = isArabic.t("تيار المحرك", "Motor Current"),
                                    summary = isArabic.t("تيار FLA: ${String.format("%.1f", viewModel.mtResultAmps)} أمبير؛ تيار الإقلاع المتوقع: ${String.format("%.1f", viewModel.mtResultAmps * 6.5)} أمبير", "FLA: ${String.format("%.1f", viewModel.mtResultAmps)} A; Startup current expected: ${String.format("%.1f", viewModel.mtResultAmps * 6.5)} A"),
                                    details = translateReport(viewModel.mtReport, isArabic)
                                )
                                Toast.makeText(context, isArabic.t("تم حفظ بيانات تيار المحرك لتكامل المنظومة اللاحقة!", "Motor analysis saved successfully!"), Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.testTag("mt_save_button")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = isArabic.t("حفظ", "Save"))
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = isArabic.t("تيار الحمل الكامل المستمر: ${String.format("%.2f", viewModel.mtResultAmps)} أمبير", "Full Load Continuous Current: ${String.format("%.2f", viewModel.mtResultAmps)} Amps"), fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text(text = isArabic.t("القاطع الحراري والمغناطيسي الموصى به: ${String.format("%.1f", viewModel.mtResultAmps * 1.25)} أمبير (قيمة تنظيمية 1.25x)", "Recommended Circuit Breaker rating: ${String.format("%.1f", viewModel.mtResultAmps * 1.25)} Amps (1.25x safety factor)"), fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = translateReport(viewModel.mtReport, isArabic), fontSize = 12.sp, lineHeight = 17.sp)
                }
            }
        }
    }
}

@Composable
fun PowerFactorCorrectionSubScreen(isArabic: Boolean, viewModel: ElectricalViewModel, context: Context) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(text = isArabic.t("حساب بنك مكثفات تصحيح معامل القدرة", "Compute Power Factor Correction Capacitor Bank"), fontWeight = FontWeight.Bold, fontSize = 16.sp)

        OutlinedTextField(
            value = viewModel.pfCurrentPowerKw,
            onValueChange = { viewModel.pfCurrentPowerKw = it },
            label = { Text(isArabic.t("القدرة الفعالة الفردية للمنشأة (كيلو واط KW)", "Plant Active Power (kW)")) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth().testTag("pf_power_input")
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = viewModel.pfOldPf,
                onValueChange = { viewModel.pfOldPf = it },
                label = { Text(isArabic.t("معامل القدرة القديم الحاصل (PF)", "Current Power Factor (PF)")) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f).testTag("pf_old_input")
            )
            OutlinedTextField(
                value = viewModel.pfTargetPf,
                onValueChange = { viewModel.pfTargetPf = it },
                label = { Text(isArabic.t("معامل القدرة المستهدف (cosφ)", "Target Power Factor (cos φ)")) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f).testTag("pf_target_input")
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = viewModel.pfVoltage,
                onValueChange = { viewModel.pfVoltage = it },
                label = { Text(isArabic.t("الجهد المغذي التوازني فولت V", "Line Voltage (Volts V)")) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f).testTag("pf_voltage_input")
            )
            OutlinedTextField(
                value = viewModel.pfFrequencyHz,
                onValueChange = { viewModel.pfFrequencyHz = it },
                label = { Text(isArabic.t("التردد الكوني هرتز Hz", "Frequency (Hz)")) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f).testTag("pf_freq_input")
            )
        }

        Button(
            onClick = { viewModel.calculatePowerFactorCorrection() },
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("pf_calc_button")
        ) {
            Text(isArabic.t("احسب قيمة جودة الطاقة وبنك المكثفات", "Calculate Power Quality & Capacitor Bank"), fontWeight = FontWeight.Bold)
        }

        if (viewModel.pfResultCapacitorKvar > 0) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp).fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = isArabic.t("بنك تحسين معامل القدرة المطلوب:", "Required Correction Capacitor Bank:"), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        IconButton(
                            onClick = {
                                viewModel.saveProject(
                                    title = isArabic.t("تحسين معامل قدرة من " + viewModel.pfOldPf + " لـ " + viewModel.pfTargetPf, "Power factor improvement " + viewModel.pfOldPf + " to " + viewModel.pfTargetPf),
                                    category = isArabic.t("معامل القدرة", "Power Factor"),
                                    summary = isArabic.t("بنك مكثفات: ${String.format("%.1f", viewModel.pfResultCapacitorKvar)} kVAr؛ سعة: ${String.format("%.1f", viewModel.pfResultCapacitanceUf)} uF", "Capacitor Bank: ${String.format("%.1f", viewModel.pfResultCapacitorKvar)} kVAr; Capacitance: ${String.format("%.1f", viewModel.pfResultCapacitanceUf)} uF"),
                                    details = translateReport(viewModel.pfReport, isArabic)
                                )
                                Toast.makeText(context, isArabic.t("تم حفظ معامل القدرة وتأريخ جودة الفولت بنجاح!", "Power factor correction project saved!"), Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.testTag("pf_save_button")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = isArabic.t("حفظ", "Save"))
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = isArabic.t("سعة بنك المكثفات الإجمالية: ${String.format("%.2f", viewModel.pfResultCapacitorKvar)} كيلو فار (kVAr)", "Total Correction Bank Capacity: ${String.format("%.2f", viewModel.pfResultCapacitorKvar)} kVAr"), fontSize = 15.sp, fontWeight = FontWeight.Bold)
                    Text(text = isArabic.t("سعة المكثف النظري: ${String.format("%.1f", viewModel.pfResultCapacitanceUf)} ميكرو فاراد (μF)", "Equivalent Individual Capacitance: ${String.format("%.1f", viewModel.pfResultCapacitanceUf)} uF"), fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = translateReport(viewModel.pfReport, isArabic), fontSize = 12.sp, lineHeight = 17.sp)
                }
            }
        }
    }
}


// -------------------------------------------------------------
// 3. SMART CIRCUIT SOLVER VIEW DEFINITION
// -------------------------------------------------------------
@Composable
fun SmartCircuitSubScreen(isArabic: Boolean, viewModel: ElectricalViewModel, context: Context) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(text = isArabic.t("حلال الدوائر الكهربائية الذكي خطوة بخطوة", "Smart Circuit Solver Step-by-Step"), fontWeight = FontWeight.Bold, fontSize = 16.sp)

        // Type of circuit solvers selection
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val filters = listOf(
                Pair("series", isArabic.t("توالي", "Series")),
                Pair("parallel", isArabic.t("توازي", "Parallel")),
                Pair("divider", isArabic.t("مقسم جهد", "Divider")),
                Pair("stardelta", isArabic.t("نجمة/دلتا", "Star/Delta"))
            )
            filters.forEach { (type, label) ->
                FilterChip(
                    selected = viewModel.circuitTypeSelected == type,
                    onClick = { viewModel.circuitTypeSelected = type },
                    label = { Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    modifier = Modifier.weight(1f).testTag("circuit_type_$type")
                )
            }
        }

        // Input forms adaptively based on solver
        val label1 = when (viewModel.circuitTypeSelected) {
            "divider" -> isArabic.t("جهد الدخل (Vin فولت)", "Input Voltage (Vin V)")
            "stardelta" -> isArabic.t("مقاومة الفرع الأول R1 أو Ra", "Branch Resistance R1 or Ra (Ω)")
            else -> isArabic.t("قيمة العنصر الأول (Comp 1)", "Component 1 Value (Ω/uF/mH)")
        }
        val label2 = when (viewModel.circuitTypeSelected) {
            "divider" -> isArabic.t("المقاومة الأولى (R1 أوم)", "First Resistor R1 (Ω)")
            "stardelta" -> isArabic.t("مقاومة الفرع الثاني R2 أو Rb", "Branch Resistance R2 or Rb (Ω)")
            else -> isArabic.t("قيمة العنصر الثاني (Comp 2 - اختياري)", "Component 2 (Opt - Ω/uF/mH)")
        }
        val label3 = when (viewModel.circuitTypeSelected) {
            "divider" -> isArabic.t("المقاومة الثانية (R2 أوم)", "Second Resistor R2 (Ω)")
            "stardelta" -> isArabic.t("مقاومة الفرع الثالث R3 أو Rc", "Branch Resistance R3 or Rc (Ω)")
            else -> isArabic.t("قيمة العنصر الثالث (Comp 3 - اختياري)", "Component 3 (Opt - Ω/uF/mH)")
        }

        // Component type selector only for series/parallel
        if (viewModel.circuitTypeSelected == "series" || viewModel.circuitTypeSelected == "parallel") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(isArabic.t("نوع المكون بالمسار: ", "Component Type: "), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Spacer(modifier = Modifier.width(8.dp))
                listOf(
                    Pair("R", isArabic.t("مقاومات Ω", "Resistors Ω")),
                    Pair("C", isArabic.t("مكثفات μF", "Capacitors µF")),
                    Pair("L", isArabic.t("محثات mH", "Inductors mH"))
                ).forEach { (type, label) ->
                    FilterChip(
                        selected = viewModel.compTypeSelected == type,
                        onClick = { viewModel.compTypeSelected = type },
                        label = { Text(label, fontSize = 12.sp) },
                        modifier = Modifier.padding(end = 6.dp).testTag("comp_type_$type")
                    )
                }
            }
        }

        // Output visualizer diagram drawn via Canvas for extreme precision
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                val modelDraw = when {
                    viewModel.circuitTypeSelected == "divider" -> SymbolDrawType.RESISTOR
                    viewModel.circuitTypeSelected == "stardelta" -> SymbolDrawType.TRANSFORMER
                    viewModel.compTypeSelected == "R" -> SymbolDrawType.RESISTOR
                    viewModel.compTypeSelected == "C" -> SymbolDrawType.CAPACITOR
                    else -> SymbolDrawType.INDUCTOR
                }
                ElectricalSymbolVisual(
                    drawType = modelDraw,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.testTag("circuit_visual_layout")
                )
            }
        }

        OutlinedTextField(
            value = viewModel.compValue1,
            onValueChange = { viewModel.compValue1 = it },
            label = { Text(label1) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth().testTag("comp1_input")
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = viewModel.compValue2,
                onValueChange = { viewModel.compValue2 = it },
                label = { Text(label2) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f).testTag("comp2_input")
            )
            OutlinedTextField(
                value = viewModel.compValue3,
                onValueChange = { viewModel.compValue3 = it },
                label = { Text(label3) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f).testTag("comp3_input")
            )
        }

        Button(
            onClick = { viewModel.solveCircuit() },
            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("circuit_solve_button")
        ) {
            Text(isArabic.t("حل الدائرة الآن خطوة بخطوة", "Solve Circuit Now Step-by-Step"), fontWeight = FontWeight.Bold)
        }

        if (viewModel.circuitStepsText.isNotEmpty()) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.2f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp).fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = isArabic.t("مكعب الحل الهندسي المعتمد:", "Approved Engineering Solving Steps:"), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        IconButton(
                            onClick = {
                                val modeLabel = when(viewModel.circuitTypeSelected) {
                                    "series" -> isArabic.t("حل توالي RLC", "Series RLC Solver")
                                    "parallel" -> isArabic.t("حل توازي RLC", "Parallel RLC Solver")
                                    "divider" -> isArabic.t("حساب مجزئ ومقسم جهد", "Voltage Divider Solver")
                                    else -> isArabic.t("تحويل نجمة ومثلث Star-Delta", "Star-Delta Conversion")
                                }
                                viewModel.saveProject(
                                    title = "$modeLabel: ${viewModel.compValue1} & ${viewModel.compValue2}",
                                    category = isArabic.t("حل الدوائر", "Circuit Solver"),
                                    summary = translateReport(viewModel.circuitResultText, isArabic),
                                    details = translateReport(viewModel.circuitStepsText, isArabic)
                                )
                                Toast.makeText(context, isArabic.t("تم حفظ تحليل الدائرة بمسودتك الميدانية!", "Circuit analysis successfully saved!"), Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.testTag("circuit_save_button")
                        ) {
                            Icon(imageVector = Icons.Default.Add, contentDescription = isArabic.t("حفظ", "Save"))
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = translateReport(viewModel.circuitResultText, isArabic), fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = translateReport(viewModel.circuitStepsText, isArabic), fontSize = 12.sp, lineHeight = 18.sp)
                }
            }
        }
    }
}


// -------------------------------------------------------------
// 4. TERMS AND SYMBOLS LIBRARY VIEW DEFINITION
// -------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LibraryScreen(isArabic: Boolean) {
    var selectedCategory by rememberSaveable { mutableStateOf("symbols") } // "symbols" (رموز), "laws" (قوانين), "glossary" (مصطلحات)
    var searchQuery by rememberSaveable { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(
            selectedTabIndex = when(selectedCategory) {
                "symbols" -> 0
                "laws" -> 1
                else -> 2
            }
        ) {
            Tab(selected = selectedCategory == "symbols", onClick = { selectedCategory = "symbols" }, text = { Text(isArabic.t("الرموز الكهربائية", "Electrical Symbols")) })
            Tab(selected = selectedCategory == "laws", onClick = { selectedCategory = "laws" }, text = { Text(isArabic.t("المعادلات والقوانين", "Equations & Laws")) })
            Tab(selected = selectedCategory == "glossary", onClick = { selectedCategory = "glossary" }, text = { Text(isArabic.t("قاموس المصطلحات", "Terminology Glossary")) })
        }

        // Search bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text(isArabic.t("ابحث بالكلمات المفتاحية...", "Search with keywords...")) },
            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = isArabic.t("بحث", "Search")) },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("lib_search_bar")
        )

        // Contents
        Box(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp)
        ) {
            when (selectedCategory) {
                "symbols" -> SymbolsList(isArabic, searchQuery)
                "laws" -> LawsList(isArabic, searchQuery)
                "glossary" -> GlossaryList(isArabic, searchQuery)
            }
        }
    }
}

@Composable
fun SymbolsList(isArabic: Boolean, query: String) {
    val filteredSymbols = ElectricalDataProvider.symbols.filter {
        it.name.contains(query, true) || it.englishName.contains(query, true) || it.symbolText.contains(query, true)
    }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(filteredSymbols) { symbol ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Row(
                    modifier = Modifier
                        .padding(12.dp)
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Vector canvas drawing
                    Box(
                        modifier = Modifier
                            .size(80.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surface),
                        contentAlignment = Alignment.Center
                    ) {
                        ElectricalSymbolVisual(
                            drawType = symbol.drawType,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(70.dp).testTag("symbol_draw_${symbol.englishName}")
                        )
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = isArabic.t(symbol.name, symbol.englishName), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            SuggestionChip(
                                onClick = {},
                                label = { Text(isArabic.t("رمز: ${symbol.symbolText}", "Symbol: ${symbol.symbolText}"), fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                            )
                        }
                        Text(text = isArabic.t("الاسم بالتأريخ: ${symbol.englishName}", "System Designation: ${symbol.englishName}"), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        val unitLabel = if (symbol.unit.contains("أوم")) "Ohms (Ω)" else if (symbol.unit.contains("ميكرو")) "Microfarads (uF / F)" else if (symbol.unit.contains("هنري")) "Henries (mH / H)" else symbol.unit
                        Text(text = isArabic.t("وحدة القياس الميدانية: ${symbol.unit}", "Standard Unit: $unitLabel"), fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                        Spacer(modifier = Modifier.height(4.dp))
                        val safeDescription = isArabic.t(symbol.description, when(symbol.englishName) {
                            "Resistor" -> "A component that limits electric current flow in the circuit and dissipates energy as heat."
                            "Capacitor" -> "Stores energy in an electric field. Passes AC power and blocks DC currents."
                            "Inductor" -> "Stores energy in a magnetic field when current flows through it, and resists sudden changes in current intensity."
                            "Diode" -> "Allows current to pass in one direction only (forward bias) and blocks it in the reverse direction to shield circuits."
                            "Ground" -> "A reference node for electrical installations, used to drain leakage and safely discharge shocks."
                            "DC Voltage Source" -> "Maintains a constant voltage potential over time (like batteries), flowing charges in a single directed path."
                            "AC Voltage Source" -> "Produces alternating voltage cycling over frequency (like domestic utility line feeds)."
                            "Transformer" -> "Steps up or steps down alternating voltage levels through electromagnetic induction at constant frequency."
                            else -> symbol.description
                        })
                        Text(text = safeDescription, fontSize = 12.sp, lineHeight = 16.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
fun LawsList(isArabic: Boolean, query: String) {
    val filteredLaws = ElectricalDataProvider.laws.filter {
        it.title.contains(query, true) || it.formula.contains(query, true)
    }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(filteredLaws) { law ->
            val englishTitle = when(law.title) {
                "قانون أوم الأساسي" -> "Ohm's Law"
                "قانون القدرة الكهربائية (أحادية المرحلة)" -> "Electric Power Law (Single Phase)"
                "معاوقة المكثف (المفاعلة السعوية)" -> "Capacitive Reactance (Xc)"
                "معاوقة الملف (المفاعلة الحثية)" -> "Inductive Reactance (Xl)"
                "تحويل النجمة والمثلث (Star-Delta)" -> "Star-Delta Conversion"
                else -> law.title
            }
            val englishDescription = when(law.title) {
                "قانون أوم الأساسي" -> "The fundamental law relating voltage, current, and resistance. It states that current flowing through a conductor is directly proportional to voltage and inversely proportional to resistance."
                "قانون القدرة الكهربائية (أحادية المرحلة)" -> "Relationships evaluating electrical power. Active power (P) in Watts, Apparent power (S) in Volt-Amperes, and Reactive power (Q) in VAr. cos(φ) is the Power Factor."
                "معاوقة المكثف (المفاعلة السعوية)" -> "Capacitor resistance to Alternating Current. This reactance decreases as frequency (f) or capacitance (C) increases. Pure DC is blocked since frequency is zero (reactance becomes infinite)."
                "معاوقة الملف (المفاعلة الحثية)" -> "Coil resistance against Alternating Current. Increases proportionally as frequency (f) or self-inductance (L) grows. For DC, reactance is zero."
                "تحويل النجمة والمثلث (Star-Delta)" -> "Used to simplify and solve complex resistor networks and three-phase circuits that cannot be solved by typical series or parallel rules."
                else -> law.description
            }
            val englishExamples = when(law.title) {
                "قانون أوم الأساسي" -> "Example: A lamp of 24 Ohms connected to a 12V source has a current of:\nI = 12 / 24 = 0.5 A."
                "قانون القدرة الكهربائية (أحادية المرحلة)" -> "Example: A motor drawing 10A at 220V with a power factor of 0.8 has:\nActive Power P = 220 × 10 × 0.8 = 1760 Watts (1.76 kW)."
                "معاوقة المكثف (المفاعلة السعوية)" -> "Example: A 10uF capacitor connected at 50 Hz frequency:\nXc = 1 / (2 × 3.1416 × 50 × 10^-5) ≈ 318.3 Ohms."
                "معاوقة الملف (المفاعلة الحثية)" -> "Example: A 0.1 Henry coil at 50 Hz frequency:\nXl = 2 × 3.1416 × 50 × 0.1 ≈ 31.4 Ohms."
                "تحويل النجمة والمثلث (Star-Delta)" -> "Extremely helpful in analyzing large motor starters and designing industrial control panels on active field sites."
                else -> law.examples
            }

            Card(
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = isArabic.t(law.title, englishTitle), fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    // Formula Card Display Background
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .padding(12.dp)
                                .fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = law.formula,
                                fontSize = 18.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = isArabic.t(law.description, englishDescription), fontSize = 13.sp, lineHeight = 18.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = isArabic.t(law.examples, englishExamples),
                        fontSize = 12.sp,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                        color = Color(0xFFE65100),
                        lineHeight = 16.sp
                    )
                }
            }
        }
    }
}

@Composable
fun GlossaryList(isArabic: Boolean, query: String) {
    val filteredGlossary = ElectricalDataProvider.glossary.filter {
        it.term.contains(query, true) || it.englishTerm.contains(query, true) || it.definition.contains(query, true)
    }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(filteredGlossary) { item ->
            val engCategory = when(item.category) {
                "أساسيات" -> "Basics"
                "جودة الطاقة" -> "Power Quality"
                "شبكات القوى" -> "Power Grids"
                "آلات ومعدات" -> "Machines & Equip"
                "التمديدات الكهربائية" -> "Electrical Wiring"
                else -> item.category
            }
            val engDefinition = when(item.term) {
                "فرق الجهد الكهربائي" -> "The electromotive force that drives electrons through a conductor from a higher potential point to a lower potential point, measured in Volts."
                "التيار الكهربائي" -> "The rate of electric charge (electron) flow through a specific conductor cross-section per unit of time, measured in Amperage."
                "معامل القدرة" -> "The ratio between active power (actually consumed) and total or apparent power drawn, indicating energy usage efficiency."
                "التيار المتناوب / المتردد" -> "An electric current whose direction and magnitude change periodically with a constant frequency over time, utilized in utilities and residential grids."
                "التيار المستمر" -> "A steady electric current flowing in a single direction over time, primarily sourced from cells, batteries, or solar panels."
                "الحث الكهرومغناطيسي" -> "Generating an electromotive force (induced voltage) in a conductor due to its exposure to a time-varying magnetic flux, the basis of generators."
                "عتبة هبوط الجهد السلكي" -> "The voltage drop along a conductor line caused by cable resistance. It is recommended not to exceed 3% for branch lines and 5% for utility feeders."
                "تيار بدء التشغيل" -> "The sudden high inrush current drawn by an electric machine or motor during initial startup to overcome inertia, typically 5-8 times full load current."
                else -> item.definition
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)),
                border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = isArabic.t(item.term, item.englishTerm), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            text = isArabic.t(item.category, engCategory),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Text(text = item.englishTerm, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f))
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(text = isArabic.t(item.definition, engDefinition), fontSize = 12.sp, lineHeight = 16.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}


// -------------------------------------------------------------
// 5. TEST & COMPREHENSIVE QUIZ VIEW DEFINITION
// -------------------------------------------------------------
@Composable
fun QuizScreen(isArabic: Boolean, viewModel: ElectricalViewModel) {
    val q = viewModel.currentQuestion

    // Custom translations for static quiz questions and explanations
    val displayQuestionText = when (q.id) {
        1 -> isArabic.t("ماذا يحدث للمقاومة الكهربائية لسلك موصل من النحاس عند زيادة قطره (مساحة المقطع) مع ثبوت الطول؟", "What happens to the electrical resistance of a copper conductor when its diameter (cross-section) increases while keeping length constant?")
        2 -> isArabic.t("أي من العلاقات التالية يمثل قانون أوم لحساب شدة التيار الكهربائي؟", "Which of the following equations represents Ohm’s law for calculating electric current?")
        3 -> isArabic.t("سلك كهربائي مغذٍ يمتد لمسافة طويلة بالمنشأة، ما هو السبب الأساسي لضرورة تكبير مقطع السلك عن القيمة المحسوبة بالحمل لتجنب الهبوط؟", "In a feeder wire extending over a long distance, what is the main reason to increase the wire size over the standard calculated value?")
        4 -> isArabic.t("في توصيل المقاومات على التوازي داخل الدائرة الكهربائية المبسطة، كيف تكون قيمة المقاومة المكافئة الإجمالية؟", "In parallel resistor networks, how is the total equivalent resistance calculated?")
        5 -> isArabic.t("ما هو التأثير المباشر والخطير لانخفاض قيم معامل القدرة (Power Factor) بالمنشآت والمصانع الكبرى؟", "What is the direct, critical consequence of low Power Factor in industrial installations?")
        6 -> isArabic.t("كيف يسلك المكثف كعنصر كهربائي في بيئة دوائر التيار المستمر (Pure DC Grid) المستقرة تماماً؟", "How does a capacitor behave in a steady-state Pure DC circuit?")
        7 -> isArabic.t("ما هي القيمة الموصى بها كأقصى حد مسموح ومقبول لنسبة هبوط الجهد (Voltage Drop) في كابلات التغذية الكهربائية الفرعية للأحمال المعتادة؟", "What is the standard maximum recommended voltage drop ratio for branch circuits?")
        8 -> isArabic.t("ما هو المبدأ الأساسي الذي يقوم عليه تشغيل المحول الكهربائي (Transformer) لرفع أو خفض مستويات الجهد للتيار المتردد؟", "What is the underlying operating principle of electrical transformers?")
        9 -> isArabic.t("في الدوائر ثلاثية الأطوار المتزنة (Balanced 3-Phase Syst.) بصيغة النجمة Star (Y)، ما هي العلاقة التي تربط جهد الخط والوجه؟", "In a balanced 3-Phase Star (Y) system, what is the mathematical relationship between Line Voltage and Phase Voltage?")
        10 -> isArabic.t("لماذا يحمل محرك كهربائي ثلاثي الأطوار يبدأ التوصيل بنجمة-دلتا (Star-Delta Starter) حماية بدء من التيارات الفائقة؟", "Why do large 3-phase motors utilize Star-Delta starters initially?")
        else -> q.question
    }

    val displayOptions = when (q.id) {
        1 -> listOf(
            isArabic.t("تزداد المقاومة الكهربائية بالمسار.", "The electrical resistance of the path increases."),
            isArabic.t("تقل المقاومة الكهربائية بالمسار.", "The electrical resistance of the path decreases."),
            isArabic.t("تظل ثابتة ولا تتأثر أبداً بالقطر.", "It remains constant and is not influenced by diameter."),
            isArabic.t("تتغير بشكل عشوائي ومبهم.", "It changes randomly.")
        )
        2 -> listOf(
            isArabic.t("شدة التيار (I) = الجهد (V) × المقاومة (R)", "Current (I) = Voltage (V) × Resistance (R)"),
            isArabic.t("شدة التيار (I) = المقاومة (R) / الجهد (V)", "Current (I) = Resistance (R) / Voltage (V)"),
            isArabic.t("شدة التيار (I) = الجهد (V) / المقاومة (R)", "Current (I) = Voltage (V) / Resistance (R)"),
            isArabic.t("شدة التيار (I) = الجهد تربيع ÷ القدرة", "Current (I) = Voltage squared / Power")
        )
        3 -> listOf(
            isArabic.t("لأن المقاومة الكهربائية تزيد بزيادة طول السلك، مسببة زيادة هبوط الجهد المتوقع.", "Because resistance increases as wire length increases, causing higher cumulative voltage drop."),
            isArabic.t("لتسهيل عملية تمديد السلاك داخل مجاري الحوائط فقط.", "To simplify wire routing inside wall conduits only."),
            isArabic.t("لتقليل تكاليف الحماية من الصواعق الكونية الخاطفة.", "To minimize protection costs from space lightning strikes."),
            isArabic.t("لأن التيارات المترددة تجذب ذرات الغبار الكروية للسلك الطويل.", "Because alternating currents attract spherical dust particles.")
        )
        4 -> listOf(
            isArabic.t("تكون دائماً أكبر من أكبر مقاومة بالدائرة.", "It is always greater than the largest individual resistance."),
            isArabic.t("تساوي حاصل جمع جميع قيم المقاومات مضافاً لها معامل الجهد.", "It equals the sum of all individual resistances plus the voltage coefficient."),
            isArabic.t("تكون دائماً أصغر من أصغر مقاومة متصلة بالدائرة التوازية.", "It is always smaller than the smallest individual resistance connected in parallel."),
            isArabic.t("نفس قيمة المقاومة الأبهج والوسطى فقط.", "Exactly equals the average middle resistance.")
        )
        5 -> listOf(
            isArabic.t("انخفاض شدة وهج مصابيح الإشارة واللوحات.", "Slight dimming of indicators and panel lights."),
            isArabic.t("زيادة سحب التيار غير الفعال (Reactive) مما يعرض المنشأة لغرامات مالية من شركة توزيع الكهرباء ويحمل الكابلات والمحولات تياراً إضافياً.", "Increased reactive current draw, overloading lines and transformers, triggering heavy utility fines."),
            isArabic.t("زيادة كفاءة وجودة تشغيل المحركات والمولدات تلقائياً.", "Automatically improving running efficiency of magnetic motors."),
            isArabic.t("تحويل التيار المتردد المغذي إلى تيار مستمر صافٍ.", "Converting incoming supply AC directly into steady DC.")
        )
        6 -> listOf(
            isArabic.t("يسلك كشورت سيركت (دائرة قصر بممر توصيل تام).", "Behaves as a short circuit (perfect conducting path)."),
            isArabic.t("يسلك كأوبن سيركت (دائرة مفتوحة تمنع مرور التيار تماماً بعد اكتمال شحنه).", "Behaves as an open circuit (blocking current completely once fully charged)."),
            isArabic.t("يحافظ على تذبذب التيار الكهربائي بتردد 50 هرتز دوماً.", "Keeps the line oscillating at exactly 50 Hz."),
            isArabic.t("يقوم بتحويل الطاقة المخزونة بداخله إلى طاقة مغناطيسية حثية.", "Converts stored electric field energy into magnetic inductance.")
        )
        7 -> listOf(
            isArabic.t("من 15% إلى 20% كنسبة معيارية.", "15% to 20% as a standard."),
            isArabic.t("من 3% إلى 5% فقط لضمان سلامة تشغيل الأجهزة بكفاءة.", "3% to 5% safe limit for standard electrical equipment."),
            isArabic.t("لا يهم أبداً هبوط الجهد طالما يتوفر لدينا حماية تيار زائد.", "Voltage drop is irrelevant as long as overcurrent circuit breakers are used."),
            isArabic.t("الهبوط المقبول هو 0% بشكل دائم وقاطع.", "The allowed drop is always 0% globally.")
        )
        8 -> listOf(
            isArabic.t("ظاهرة الحث الكهرومغناطيسي المتبادل (Mutual Induction).", "Mutual Electromagnetic Induction."),
            isArabic.t("قوانين الجذب المادي وقوة الجاذبية الأرضية.", "Physical laws of gravitational pull."),
            isArabic.t("الاحتكاك الميكانيكي اليدوي لشرائح السيلكون الصلب.", "Mechanical friction of silicon sheets."),
            isArabic.t("التحليل الكيميائي لغاز النيتروجين المخزن بحوض الزيت.", "Chemical breakdown of nitrogen gas stored in premium cooling oil.")
        )
        9 -> listOf(
            isArabic.t("جهد الخط (Line Voltage) يساوي تماماً جهد الوجه (Phase Voltage).", "Line Voltage equals Phase Voltage."),
            isArabic.t("جهد الخط (V_line) = جذر 3 × جهد الوجه (V_phase).", "Line Voltage (V_line) = √3 × Phase Voltage (V_phase)."),
            isArabic.t("جهد الخط (V_line) = جهد الوجه (V_phase) مقسوماً على 2.", "Line Voltage (V_line) = Phase Voltage (V_phase) / 2."),
            isArabic.t("جهد الخط = صفر دائماً لأن خط المتوازن متقاطع.", "Line Voltage is always zero in a balanced grid.")
        )
        10 -> listOf(
            isArabic.t("لأن تيار التحميل الفردي يتبخر بالملفات النحاسية تدريجياً.", "Because standard mechanical load current gradually dissipates in the copper lines."),
            isArabic.t("لتقليل تيار الإقلاع العالي (Inrush) الذي يبلغ 5-8 أضعاف تيار التشغيل وتخفيف الهبوط بالشبكة عند لحظة البدء.", "To minimize high inrush current (typically 5-8 times nominal) and safeguard the supply grid from voltage drops."),
            isArabic.t("لتسريع تشغيل المحرك الكهربائي وتوصيله بأقصى طاقة ميكانيكية بـ 0.1 ثانية.", "To accelerate full motor startup to peak mechanical torque in 0.1 seconds."),
            isArabic.t("لتغيير اتجاه دوران المحرك بشكل أوتوماتيكي سريع.", "To automatically switch the direction of rotation quick.")
        )
        else -> q.options
    }

    val displayExplanation = when (q.id) {
        1 -> isArabic.t("المقاومة الكهربائية تتناسب عكسياً مع مساحة مقطع السلك (R = ρ × L / A). وبالتالي عند زيادة القطر ومساحة المقطع تسهل حركة الإلكترونات وتقل المقاومة الكلية للخط.", "Electrical resistance is inversely proportional to cross-sectional area (R = ρ × L / A). Increasing cross-section allows easier electron flow, decreasing the path resistance.")
        2 -> isArabic.t("طبقاً لقانون أوم، التيار يساوي الجهد مقسوماً على المقاومة (I = V / R). وهي العلاقة الخطية الأساسية بالكهرباء.", "According to Ohm's law, current equals voltage divided by resistance (I = V / R), which is the primary linear relationship in electrical circuits.")
        3 -> isArabic.t("بسبب العلاقة الطردية بين طول السلك للمسافات الطويلة والمقاومة (R = ρ × L / A)، تزيد المقاومة وكلما زادت زاد هبوط الجهد (V_drop = I × R) مما يجعل تكبير مقطع السلك حتمياً لتقليص المقاومة.", "Due to the proportional relation between length and electrical resistance (R = ρ × L / A), resistance accumulates over distance, which causes higher voltage drop (V_drop = I × R).")
        4 -> isArabic.t("بالتوازي يقل الطول المكافئ لمسار مرور التيار الإجمالي ويكافئ مقلوب المقاومات (1 / Req = 1 / R1 + 1 / R2 + ...). لذا تصبح المقاومة المكافئة الكلية أصغر من أصغر مقاومة فردية بالمسارات.", "In parallel, adding branches increases pathways for electron flow. Total equivalent resistance is smaller than any individual path (1 / Req = 1 / R1 + 1 / R2 + ...).")
        5 -> isArabic.t("معامل القدرة المنخفض يعني سحب كمية طاقة غير فعالة عالية دون فائدة فيزيائية ملموسة، تيار الحمل الكلي يسحب بكميات متزايدة لتعويض الفارق مما يتسبب في إجهاد وارتفاع حرارة الكابلات والمحولات، وتفرض شركات التوزيع عقوبات وغرامات قاسية بسببه.", "Low PF implies high reactive energy consumption without physical output, overloading distribution lines and running up power utility penalty tariffs.")
        6 -> isArabic.t("في التيار المستمر يكون التردد صفراً (f = 0). المفاعلة السعوية للمكثف هي (Xc = 1 / (2 × π × f × C))، وبالتعويض بتردد صفر نحصل على معاوقة لا نهائية، مما يجعله يعمل كدائرة مفتوحة تمنع تدفق التيار المستمر بعد الشحن.", "Under steady DC, frequency is zero. Substituting f=0 in capacitive reactance (Xc = 1 / [2 * pi * f * C]) yields infinite reactance, making it block current like an open circuit.")
        7 -> isArabic.t("التوصية المعيارية للأكواد الكهربائية الوطنية (NEC, IEC) تنص على ألا تزيد نسبة هبوط الجهد الكلي عن 3% لدوائر الإنارة والأحمال الفرعية، و5% كحد أقصى لكابلات التغذية الرئيسية للحفاظ على أداء الأجهزة واستقرار الكفاءة.", "NEC & IEC specify maximum cumulative voltage drop not to exceed 3% for branch networks and 5% for principal feed cables.")
        8 -> isArabic.t("يعتمد تشغيل المحول على الحث المتبادل بين ملفين (ابتدائي وثانوي) يحيطان بقلب حديدي ناقل للفيض المغناطيسي. يؤدي مرور تيار متردد في الملف الابتدائي لتوليد فيض مغناطيسي متغير، يقطع الملف الثانوي ويستحث فيه جهداً متغيراً طردياً مع نسبة عدد اللفات.", "A transformer leverages mutual induction between primary and secondary windings linked via a magnetic core.")
        9 -> isArabic.t("في ربط النجمة المتزن يحمل التيار في الخط نفس قيمة تيار العضو الفردي، بينما يكون جهد الخط (بين خطين) أعلى من جهد الوجه (بين خط والنيوترال) بمقدار معامل الجهد لجيب الزاوية 120 درجة وتكافئ رياضياً: V_line = √3 × V_phase.", "In a balanced Star configuration, line current equals phase current, while Line-to-Line voltage is larger than Line-to-Neutral voltage by factor of √3: V_line = √3 × V_phase.")
        10 -> isArabic.t("مفتاح البداية بنجمة يقلص الجهد المطبق على ملفات كل طور بنسبة 1/3√ مما يقلل تيار الإقلاع المبدئي بمقدار الثلث، ممتصاً الضغط الفجائي العالي والتيار المندفع عن الشبكة قبل التحول لوضع المثلث المستقر للتشغيل الطبيعي بكامل القدرة.", "Star configuration drops applied phase voltage to 1/√3, which limits starting inrush current to 1/3, mitigating grid voltage dips before shifting to high-torque Delta configuration.")
        else -> q.explanation
    }

    Card(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            if (!viewModel.isQuizFinished) {
                // Header of status
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = isArabic.t("السؤال: ${viewModel.currentQuestionIndex + 1} / ${ElectricalDataProvider.quizQuestions.size}", "Question: ${viewModel.currentQuestionIndex + 1} / ${ElectricalDataProvider.quizQuestions.size}"),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = isArabic.t("الدرجة الصحيحة: ${viewModel.correctCount}", "Correct Answers: ${viewModel.correctCount}"),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color(0xFF2E7D32)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                
                // Progress Bar
                LinearProgressIndicator(
                    progress = { (viewModel.currentQuestionIndex + 1).toFloat() / ElectricalDataProvider.quizQuestions.size.toFloat() },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))
                
                // Question text
                Text(
                    text = displayQuestionText,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    lineHeight = 22.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                
                Spacer(modifier = Modifier.height(18.dp))

                // Answer options selectors with click feedback ripples
                displayOptions.forEachIndexed { idx, option ->
                    val isSelected = viewModel.selectedOptionIndex == idx
                    val cardBg = when {
                        viewModel.isAnswerChecked && idx == q.correctIndex -> Color(0xFFC8E6C9) // Green for correct answer
                        viewModel.isAnswerChecked && isSelected && isSelected != (idx == q.correctIndex) -> Color(0xFFFFCDD2) // Red for wrong selected
                        isSelected -> MaterialTheme.colorScheme.primaryContainer
                        else -> MaterialTheme.colorScheme.surface
                    }
                    val borderOutline = when {
                        viewModel.isAnswerChecked && idx == q.correctIndex -> Color(0xFF2E7D32)
                        viewModel.isAnswerChecked && isSelected && isSelected != (idx == q.correctIndex) -> Color(0xFFC62828)
                        isSelected -> MaterialTheme.colorScheme.primary
                        else -> MaterialTheme.colorScheme.outlineVariant
                    }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 5.dp)
                            .testTag("quiz_option_$idx")
                            .clickable { viewModel.selectOption(idx) },
                        colors = CardDefaults.cardColors(containerColor = cardBg),
                        border = BorderStroke(1.dp, borderOutline)
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(12.dp)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${idx + 1}. ",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 14.sp
                            )
                            Text(
                                text = option,
                                fontSize = 13.sp,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Verification and control triggers
                if (!viewModel.isAnswerChecked) {
                    Button(
                        onClick = { viewModel.checkAnswer() },
                        enabled = viewModel.selectedOptionIndex != null,
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("quiz_verify_button")
                    ) {
                        Text(isArabic.t("تحقق من صحة الإجابة", "Verify Answer Quality"), fontWeight = FontWeight.Bold)
                    }
                } else {
                    // Action description feedback explanation card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            val alertTitle = if (viewModel.selectedOptionIndex == q.correctIndex) {
                                isArabic.t("أحسنت! إجابة هندسية صحيحة 💯", "Excellent! Correct engineering answer 💯")
                            } else {
                                isArabic.t("للأسف، إجابة غير دقيقة.", "Unfortunately, that is incorrect.")
                            }
                            Text(
                                text = alertTitle,
                                fontWeight = FontWeight.Bold,
                                color = if (viewModel.selectedOptionIndex == q.correctIndex) Color(0xFF2E7D32) else Color(0xFFC62828),
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = displayExplanation,
                                fontSize = 12.sp,
                                lineHeight = 16.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Button(
                        onClick = { viewModel.nextQuestion() },
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("quiz_next_button")
                    ) {
                        Text(
                            text = if (viewModel.currentQuestionIndex == ElectricalDataProvider.quizQuestions.size - 1) {
                                isArabic.t("عرض تقييمك الكهربائي", "Show Final Electrical Score")
                            } else {
                                isArabic.t("السؤال التالي", "Next Question")
                            },
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            } else {
                // Quiz completed success metrics
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "تم",
                        tint = Color(0xFFF97316),
                        modifier = Modifier.size(72.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = isArabic.t("تهانينا! أكملت اختبار التقييم الميداني بنجاح", "Congratulations! Evaluation Test Completed Successfully"),
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = isArabic.t("درجتك النهائية: ${viewModel.correctCount} من ${ElectricalDataProvider.quizQuestions.size} أسئلة صحيحة", "Final Score: ${viewModel.correctCount} out of ${ElectricalDataProvider.quizQuestions.size} correct"),
                        fontSize = 16.sp,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    
                    val ratingStr = when {
                        viewModel.correctCount >= 9 -> isArabic.t("المستوى الفني: مهندس استشاري فذ محترف! ⚡", "Rank: Fidgetless Consultant Engineer! ⚡")
                        viewModel.correctCount >= 6 -> isArabic.t("المستوى الفني: مهندس موقع متمكن وقارئ جيد.", "Rank: Knowledgeable Site Engineer.")
                        else -> isArabic.t("المستوى الفني: مبتدئ/ فني صيانة - نوصي بمراجعة قاموس المصطلحات والرموز.", "Rank: Junior Technician / Maintenance Aide.")
                    }
                    Text(text = ratingStr, fontSize = 13.sp, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic, modifier = Modifier.padding(vertical = 8.dp), color = Color(0xFFE65100))

                    Spacer(modifier = Modifier.height(24.dp))
                    Button(
                        onClick = { viewModel.restartQuiz() },
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("quiz_restart_button")
                    ) {
                        Text(isArabic.t("إعادة تصفير البدء بالاختبار", "Restart Assessment Quiz"), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}


// -------------------------------------------------------------
// 6. GEMINI AI TECHNICAL MENTOR VIEW DEFINITION
// -------------------------------------------------------------
@Composable
fun AiAssistantScreen(isArabic: Boolean, viewModel: ElectricalViewModel) {
    Card(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp).fillMaxSize()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.Info, contentDescription = isArabic.t("ذكاء", "Intelligence"), tint = MaterialTheme.colorScheme.primary)
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(text = isArabic.t("المستشار التقني الفوري والذكي", "AI Instant Technical Advisor"), fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(text = isArabic.t("مدعوم بنظام Gemini لحل المسائل المعقدة", "AI-powered Gemini system for solving industrial queries"), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Spacer(modifier = Modifier.height(12.dp))

            // Chat response screen
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(0.5.dp, MaterialTheme.colorScheme.outlineVariant),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                Box(modifier = Modifier.fillMaxSize().padding(14.dp)) {
                    if (viewModel.isAiLoading) {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            CircularProgressIndicator()
                            Spacer(modifier = Modifier.height(12.dp))
                            Text(text = isArabic.t("جاري تجميع وتحليل البيانات للمسألة الكهربائية...", "Compiling and analyzing parameters for your query with Gemini..."), fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                        }
                    } else {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .verticalScroll(rememberScrollState())
                        ) {
                            // Automatically localize response body if it is the baseline helper
                            val rawResponse = viewModel.aiResponse
                            val localizedResponse = if (rawResponse.startsWith("أهلاً بك مهندسنا")) {
                                isArabic.t(
                                    rawResponse,
                                    "Welcome to your professional workspace. Ask me about the system, circuit networks, safety parameters, or standard NEC codes, or tap one of the instant keys below!"
                                )
                            } else {
                                translateReport(rawResponse, isArabic)
                            }

                            Text(
                                text = localizedResponse,
                                fontSize = 13.sp,
                                lineHeight = 18.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.testTag("ai_response_body")
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Scrollable rapid template queries
            Text(text = isArabic.t("استشارات هندسية سريعة بنقرة واحدة:", "One-Click Instant Advisor Prompts:"), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val templates = listOf(
                    isArabic.t("كيف يتم تشغيل محرك 3 فاز بنظام ستار-دلتا؟", "How does a 3-phase motor run with Star-Delta configuration?"),
                    isArabic.t("ما هي فائدة مفتاح الحماية من التسرب الأرضي ELCD بمواقع التوزيع؟", "What is the function of Earth Leakage Circuit Breakers (ELCD) in grid distribution nodes?"),
                    isArabic.t("كيف يمكن فحص ومعاينة المحولات ذات الفولت العالي؟", "What are the standard field procedures to inspect high-voltage electrical transformers?")
                )
                templates.forEach { temp ->
                    SuggestionChip(
                        onClick = { viewModel.askAi(temp) },
                        label = { Text(temp, fontSize = 11.sp) },
                        modifier = Modifier.testTag("ai_template_${temp.take(10)}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // custom send formula bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = viewModel.aiQuery,
                    onValueChange = { viewModel.aiQuery = it },
                    placeholder = { Text(isArabic.t("اطرح سؤالك أو معادلتك الصعبة...", "Ask any complex query or electrical equation...")) },
                    modifier = Modifier.weight(1f).testTag("ai_query_input")
                )
                IconButton(
                    onClick = {
                        val q = viewModel.aiQuery
                        viewModel.askAi(q)
                        viewModel.aiQuery = ""
                    },
                    enabled = viewModel.aiQuery.isNotBlank() && !viewModel.isAiLoading,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.primaryContainer)
                        .testTag("ai_send_button")
                ) {
                    Icon(imageVector = Icons.Default.Send, contentDescription = isArabic.t("أرسل", "Send"), tint = MaterialTheme.colorScheme.onPrimaryContainer)
                }
            }
        }
    }
}


// -------------------------------------------------------------
// HELPER SAVED PROJECTS LIST ITEM COMPOSABLE
// -------------------------------------------------------------
@Composable
fun SavedProjectListItem(
    isArabic: Boolean,
    project: SavedProject,
    onDelete: () -> Unit,
    onSharePdf: (Context) -> Unit
) {
    val context = LocalContext.current
    var isExpanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .clickable { isExpanded = !isExpanded },
        colors = CardDefaults.cardColors(
            containerColor = AppSurface
        ),
        border = BorderStroke(1.dp, BorderOutlineVariant)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        SuggestionChip(
                            onClick = {},
                            label = { Text(project.category, fontSize = 10.sp) }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = project.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    // Share icon to prompt pdf compilation and triggers email/whatsapp
                    IconButton(
                        onClick = { onSharePdf(context) },
                        modifier = Modifier.size(36.dp).testTag("project_share_${project.id}")
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = isArabic.t("مشاركة PDF", "Share PDF"), tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    }
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(36.dp).testTag("project_delete_${project.id}")
                    ) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = isArabic.t("حذف القول", "Delete"), tint = Color(0xFFC62828), modifier = Modifier.size(18.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = isArabic.t("الخلاصة: ", "Summary: ") + project.summary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.primary
            )

            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.padding(top = 10.dp)) {
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = project.details,
                        fontSize = 11.sp,
                        lineHeight = 16.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
